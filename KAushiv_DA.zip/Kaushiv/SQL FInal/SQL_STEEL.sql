create database Steel;
use Steel;


drop database Steel;

select * from Steel1;

###################### First Moment Business Decision / Measures of Central Tendency #############################


###  Mean  ###

SELECT AVG(`New Scrap Steel (%)`) AS mean_New_scrap_steel_percent, AVG(`BF Electricity (kWh)`) AS mean_BF_Electricity_kWh,
AVG(`EAF Electricity (kWh)`) AS mean_EAF_Electricity_kWh,AVG(`LRF Electricity (kWh)`) AS mean_LRF_Electricity_kWh,
AVG(`Total Electricity Consumption (kWh)`) AS mean_Total_Electricity_Consumption_kWh,AVG(`New Electricity Consumption (kWh) Total`) AS mean_New_Electricity_Consumption_kWh_Total,
AVG(`bF Electricity (kWh) (New)`) AS mean_BF_Electricity_kWh_New,AVG(`EAF Electricity (kWh) (New)`) AS mean_EAF_Electricity_kWh_New,
AVG(`LRF Electricity (kWh) (New)`) AS mean_LRF_Electricity_kWh_New,AVG(`Scrap Steel (%)`) AS mean_scrap_steel_percent,AVG(`Iron Ore (%)`) AS mean_Iron_Ore_percent,AVG(`New Iron Ore (%)`) AS mean_New_Iron_Ore_percent,
AVG(`New DRI or Pig Iron (%)`) AS mean_NewDRI_or_Pig_Iron_percent,AVG(`DRI or Pig Iron (%)`) AS mean_DRI_or_Pig_Iron_percent,AVG(`carbon (%)`) AS mean_carbon_percent,
AVG(`Phosphorus (%)`) AS mean_Phosphorus_percent
FROM Steel1;


###  Median  ###

SELECT `New Scrap Steel (%)` AS median_New_scrap_steel_percent, `BF Electricity (kWh)` AS median_BF_Electricity_kWh,
`EAF Electricity (kWh)` AS median_EAF_Electricity_kWh,`LRF Electricity (kWh)` AS median_LRF_Electricity_kWh,
`Total Electricity Consumption (kWh)` AS median_Total_Electricity_Consumption_kWh,`New Electricity Consumption (kWh) Total` AS median_New_Electricity_Consumption_kWh_Total,
`bF Electricity (kWh) (New)` AS median_BF_Electricity_kWh_New,`EAF Electricity (kWh) (New)` AS median_EAF_Electricity_kWh_New,
`LRF Electricity (kWh) (New)` AS median_LRF_Electricity_kWh_New,`Scrap Steel (%)` AS median_scrap_steel_percent,`Iron Ore (%)` AS median_Iron_Ore_percent,`New Iron Ore (%)` AS median_New_Iron_Ore_percent,
`New DRI or Pig Iron (%)` AS median_NewDRI_or_Pig_Iron_percent,`DRI or Pig Iron (%)` AS median_DRI_or_Pig_Iron_percent,`carbon (%)` AS median_carbon_percent,
`Phosphorus (%)` AS median_Phosphorus_percent
FROM (
SELECT `New Scrap Steel (%)`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`, `LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,
`New Electricity Consumption (kWh) Total`,`bF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,
`Scrap Steel (%)`,`Iron Ore (%)`,`New Iron Ore (%)`,`New DRI or Pig Iron (%)`,`DRI or Pig Iron (%)`,
`carbon (%)`,`Phosphorus (%)`,
ROW_NUMBER() OVER (ORDER BY `New Scrap Steel (%)`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`,`LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,
`New Electricity Consumption (kWh) Total`,`bF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,
`Scrap Steel (%)`,`Iron Ore (%)`,`New Iron Ore (%)`,`New DRI or Pig Iron (%)`,`DRI or Pig Iron (%)`,
`carbon (%)`,`Phosphorus (%)`) AS row_num,
COUNT(*) OVER () AS total_count
FROM Steel1
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;


### Mode ###

SELECT `New Scrap Steel (%)` AS mode_New_scrap_steel_percent, `BF Electricity (kWh)` AS mode_BF_Electricity_kWh,
`EAF Electricity (kWh)` AS mode_EAF_Electricity_kWh,`LRF Electricity (kWh)` AS mode_LRF_Electricity_kWh,
`Total Electricity Consumption (kWh)` AS mode_Total_Electricity_Consumption_kWh,`New Electricity Consumption (kWh) Total` AS mode_New_Electricity_Consumption_kWh_Total,
`bF Electricity (kWh) (New)` AS mode_BF_Electricity_kWh_New,`EAF Electricity (kWh) (New)` AS mode_EAF_Electricity_kWh_New,
`LRF Electricity (kWh) (New)` AS mode_LRF_Electricity_kWh_New,`Scrap Steel (%)` AS mode_scrap_steel_percent,`Iron Ore (%)` AS mode_Iron_Ore_percent,`New Iron Ore (%)` AS mode_New_Iron_Ore_percent,
`New DRI or Pig Iron (%)` AS mode_NewDRI_or_Pig_Iron_percent,`DRI or Pig Iron (%)` AS mode_DRI_or_Pig_Iron_percent,`carbon (%)` AS mode_carbon_percent,
`Phosphorus (%)` AS mode_Phosphorus_percent
FROM (
SELECT `New Scrap Steel (%)`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`, `LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,
`New Electricity Consumption (kWh) Total`,`bF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,
`Scrap Steel (%)`,`Iron Ore (%)`,`New Iron Ore (%)`,`New DRI or Pig Iron (%)`,`DRI or Pig Iron (%)`,
`carbon (%)`,`Phosphorus (%)`, count(*) as frequency from steel1
Group BY `New Scrap Steel (%)`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`,`LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,
`New Electricity Consumption (kWh) Total`,`bF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,
`Scrap Steel (%)`,`Iron Ore (%)`,`New Iron Ore (%)`,`New DRI or Pig Iron (%)`,`DRI or Pig Iron (%)`,
`carbon (%)`,`Phosphorus (%)`
ORDER BY frequency DESC
LIMIT 1
) AS subquery;
###################### Second Moment Business Decision / Measures of Dispersion #############################

######### Variance #########
use steel;
SELECT variance(`New Scrap Steel (%)`) AS variance_New_scrap_steel_percent, variance(`BF Electricity (kWh)`) AS variance_BF_Electricity_kWh,
variance(`EAF Electricity (kWh)`) AS variance_EAF_Electricity_kWh,variance(`LRF Electricity (kWh)`) AS variance_LRF_Electricity_kWh,
variance(`Total Electricity Consumption (kWh)`) AS variance_Total_Electricity_Consumption_kWh,variance(`New Electricity Consumption (kWh) Total`) AS variance_New_Electricity_Consumption_kWh_Total,
variance(`bF Electricity (kWh) (New)`) AS variance_BF_Electricity_kWh_New,variance(`EAF Electricity (kWh) (New)`) AS variance_EAF_Electricity_kWh_New,
variance(`LRF Electricity (kWh) (New)`) AS variance_LRF_Electricity_kWh_New,variance(`Scrap Steel (%)`) AS variance_scrap_steel_percent,variance(`Iron Ore (%)`) AS variance_Iron_Ore_percent,variance(`New Iron Ore (%)`) AS variance_New_Iron_Ore_percent,
variance(`New DRI or Pig Iron (%)`) AS variance_NewDRI_or_Pig_Iron_percent,variance(`DRI or Pig Iron (%)`) AS variance_DRI_or_Pig_Iron_percent,variance(`carbon (%)`) AS variance_carbon_percent,
variance(`Phosphorus (%)`) AS variance_Phosphorus_percent
FROM Steel1;

########## Standard Deviation ############

SELECT STDDEV(`New Scrap Steel (%)`) AS STDDEV_New_scrap_steel_percent, STDDEV(`BF Electricity (kWh)`) AS STDDEV_BF_Electricity_kWh,
STDDEV(`EAF Electricity (kWh)`) AS STDDEV_EAF_Electricity_kWh,STDDEV(`LRF Electricity (kWh)`) AS STDDEV_LRF_Electricity_kWh,
STDDEV(`Total Electricity Consumption (kWh)`) AS STDDEV_Total_Electricity_Consumption_kWh,STDDEV(`New Electricity Consumption (kWh) Total`) AS variance_New_Electricity_Consumption_kWh_Total,
STDDEV(`bF Electricity (kWh) (New)`) AS STDDEV_BF_Electricity_kWh_New,STDDEV(`EAF Electricity (kWh) (New)`) AS STDDEV_EAF_Electricity_kWh_New,
STDDEV(`LRF Electricity (kWh) (New)`) AS STDDEV_LRF_Electricity_kWh_New,STDDEV(`Scrap Steel (%)`) AS STDDEV_scrap_steel_percent,STDDEV(`Iron Ore (%)`) AS STDDEV_Iron_Ore_percent,STDDEV(`New Iron Ore (%)`) AS STDDEV_New_Iron_Ore_percent,
STDDEV(`New DRI or Pig Iron (%)`) AS STDDEV_NewDRI_or_Pig_Iron_percent,STDDEV(`DRI or Pig Iron (%)`) AS STDDEV_DRI_or_Pig_Iron_percent,STDDEV(`carbon (%)`) AS STDDEV_carbon_percent,
STDDEV(`Phosphorus (%)`) AS STDDEV_Phosphorus_percent
FROM Steel1;


############ Range ############

SELECT MAX(`BF Electricity (kWh)`) - MIN(`BF Electricity (kWh)`) AS range_BF_Electricity_kWh,
MAX(`EAF Electricity (kWh)`) - MIN(`EAF Electricity (kWh)`) AS range_EAF_Electricity_kWh,
MAX(`LRF Electricity (kWh)`) - MIN(`LRF Electricity (kWh)`) AS range_LRF_Electricity_kWh,
MAX(`BF Electricity (kWh) (New)`) - MIN(`BF Electricity (kWh) (New)`) AS range_BF_Electricity_kWh_New,
MAX(`EAF Electricity (kWh) (New)`) - MIN(`EAF Electricity (kWh) (New)`) AS range_EAF_Electricity_kWh_New,
MAX(`LRF Electricity (kWh) (New)`) - MIN(`LRF Electricity (kWh) (New)`) AS range_LRF_Electricity_kWh_New,
MAX(`Total Electricity Consumption (kWh)`) - MIN(`Total Electricity Consumption (kWh)`) AS range_Total_Electricity_Consumption_kWh,
MAX(`New Electricity Consumption (kWh) Total`) - MIN(`New Electricity Consumption (kWh) Total`) AS range_New_Electricity_Consumption_kWh_Total,
MAX(`Scrap Steel (%)`) - MIN(`Scrap Steel (%)`) AS range_Scrap_Steel_percent,
MAX(`New Scrap Steel (%)`) - MIN(`New Scrap Steel (%)`) AS range_New_Scrap_Steel_percent,
MAX(`New DRI or Pig Iron (%)`) - MIN(`New DRI or Pig Iron (%)`) AS range_NewDRI_or_PigIron_percent,
MAX(`DRI or Pig Iron (%)`) - MIN(`DRI or Pig Iron (%)`) AS range_DRI_or_PigIron_percent,
MAX(`Iron Ore (%)`) - MIN(`Iron Ore (%)`) AS range_Iron_Ore_percent,
MAX(`New Iron Ore (%)`) - MIN(`New Iron Ore (%)`) AS range_New_Iron_Ore_percent,
MAX(`Phosphorus (%)`) - MIN(`Phosphorus (%)`) AS range_Phosphorus_percent,
MAX(`Carbon (%)`) - MIN(`Carbon (%)`) AS range_Carbon_percent
FROM Steel1;


######################## Third Moment Business Decision / Skewness ######################

SELECT
(
SUM(POWER(`BF Electricity (kWh)`- (SELECT AVG(`BF Electricity (kWh)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`BF Electricity (kWh)`) FROM Steel1), 3))
) AS skewness_BF_Electricity_kWh,
(
SUM(POWER(`EAF Electricity (kWh)`- (SELECT AVG(`EAF Electricity (kWh)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`EAF Electricity (kWh)`) FROM Steel1), 3))
) AS skewness_EAF_Electricity_kWh,
(
SUM(POWER(`LRF Electricity (kWh)`- (SELECT AVG(`LRF Electricity (kWh)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`LRF Electricity (kWh)`) FROM steel1), 3))
) AS skewness_LRF_Electricity_kWh,
(
SUM(POWER(`BF Electricity (kWh) (New)`- (SELECT AVG(`BF Electricity (kWh) (New)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`BF Electricity (kWh) (New)`) FROM steel1), 3))
) AS skewness_BF_Electricity_kWh_New,
(
SUM(POWER(`EAF Electricity (kWh) (New)`- (SELECT AVG(`EAF Electricity (kWh) (New)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`EAF Electricity (kWh) (New)`) FROM steel1), 3))
) AS skewness_EAF_Electricity_kWh_New,
(
SUM(POWER(`LRF Electricity (kWh) (New)`- (SELECT AVG(`LRF Electricity (kWh) (New)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`LRF Electricity (kWh) (New)`) FROM Steel1), 3))
) AS skewness_LRF_Electricity_kWh_New,
(
SUM(POWER(`Total Electricity Consumption (kWh)`- (SELECT AVG(`Total Electricity Consumption (kWh)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Total Electricity Consumption (kWh)`) FROM Steel1), 3))
) AS skewness_Total_Electricity_Consumption_kWh,
(
SUM(POWER(`New Electricity Consumption (kWh) Total`- (SELECT AVG(`New Electricity Consumption (kWh) Total`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Electricity Consumption (kWh) Total`) FROM Steel1), 3))
) AS skewness_New_Electricity_Consumption_kWh_Total,
(
SUM(POWER(`Scrap Steel (%)`- (SELECT AVG(`Scrap Steel (%)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Scrap Steel (%)`) FROM Steel1), 3))
) AS skewness_Scrap_Steel_percent,
(
SUM(POWER(`New Scrap Steel (%)`- (SELECT AVG(`New Scrap Steel (%)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Scrap Steel (%)`) FROM Steel1), 3))
) AS skewness_New_Scrap_Steel_percent,
(
SUM(POWER(`Iron Ore (%)`- (SELECT AVG(`Iron Ore (%)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Iron Ore (%)`) FROM steel1), 3))
) AS skewness_Iron_Ore_percent,
(
SUM(POWER(`New Iron Ore (%)`- (SELECT AVG(`New Iron Ore (%)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Iron Ore (%)`) FROM steel1), 3))
) AS skewness_New_Iron_Ore_percent,
(
SUM(POWER(`DRI or Pig Iron (%)`- (SELECT AVG(`DRI or Pig Iron (%)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`DRI or Pig Iron (%)`) FROM steel1), 3))
) AS skewness_DRI_or_PigIron_percent,
(
SUM(POWER(`New DRI or Pig Iron (%)`- (SELECT AVG(`New DRI or Pig Iron (%)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`New DRI or Pig Iron (%)`) FROM Steel1), 3))
) AS skewness_NewDRI_or_PigIron_percent,
(
SUM(POWER(`Phosphorus (%)`- (SELECT AVG(`Phosphorus (%)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Phosphorus (%)`) FROM Steel1), 3))
) AS skewness_Phosphorus_percent,
(
SUM(POWER(`Carbon (%)`- (SELECT AVG(`Carbon (%)`) FROM Steel1), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Carbon (%)`) FROM Steel1), 3))
) AS skewness_Carbon_percent
FROM Steel1;

############################### Fourth Moment Business Decision / Kurtosis #####################################

SELECT
(
(SUM(POWER(`BF Electricity (kWh)`- (SELECT AVG(`BF Electricity (kWh)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`BF Electricity (kWh)`) FROM Steel1), 4)))-3 
)AS kurtosis_BF_Electricity_kWh,
(
(SUM(POWER(`EAF Electricity (kWh)`- (SELECT AVG(`EAF Electricity (kWh)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`EAF Electricity (kWh)`) FROM Steel1), 4)))-3
) AS kurtosis_EAF_Electricity_kWh,
(
(SUM(POWER(`LRF Electricity (kWh)`- (SELECT AVG(`LRF Electricity (kWh)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`LRF Electricity (kWh)`) FROM steel1), 4)))-3
) AS kurtosis_LRF_Electricity_kWh,
(
(SUM(POWER(`BF Electricity (kWh) (New)`- (SELECT AVG(`BF Electricity (kWh) (New)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`BF Electricity (kWh) (New)`) FROM steel1), 4)))-3
) AS skewness_BF_Electricity_kWh_New,
(
(SUM(POWER(`EAF Electricity (kWh) (New)`- (SELECT AVG(`EAF Electricity (kWh) (New)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`EAF Electricity (kWh) (New)`) FROM steel1), 4)))-3
) AS kurtosis_EAF_Electricity_kWh_New,
(
(SUM(POWER(`LRF Electricity (kWh) (New)`- (SELECT AVG(`LRF Electricity (kWh) (New)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`LRF Electricity (kWh) (New)`) FROM Steel1), 4)))-3
) AS kurtosis_LRF_Electricity_kWh_New,
(
(SUM(POWER(`Total Electricity Consumption (kWh)`- (SELECT AVG(`Total Electricity Consumption (kWh)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Total Electricity Consumption (kWh)`) FROM Steel1), 4)))-3
) AS kurtosis_Total_Electricity_Consumption_kWh,
(
(SUM(POWER(`New Electricity Consumption (kWh) Total`- (SELECT AVG(`New Electricity Consumption (kWh) Total`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Electricity Consumption (kWh) Total`) FROM Steel1), 4)))-3
) AS kurtosis_New_Electricity_Consumption_kWh_Total,
(
(SUM(POWER(`Scrap Steel (%)`- (SELECT AVG(`Scrap Steel (%)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Scrap Steel (%)`) FROM Steel1), 4)))-3
) AS kurtosis_Scrap_Steel_percent,
(
(SUM(POWER(`New Scrap Steel (%)`- (SELECT AVG(`New Scrap Steel (%)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Scrap Steel (%)`) FROM Steel1), 4)))-3
) AS kurtosis_New_Scrap_Steel_percent,
(
(SUM(POWER(`Iron Ore (%)`- (SELECT AVG(`Iron Ore (%)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Iron Ore (%)`) FROM steel1), 4)))-3
) AS kurtosis_Iron_Ore_percent,
(
(SUM(POWER(`New Iron Ore (%)`- (SELECT AVG(`New Iron Ore (%)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Iron Ore (%)`) FROM steel1), 4)))-3
) AS kurtosis_New_Iron_Ore_percent,
(
(SUM(POWER(`DRI or Pig Iron (%)`- (SELECT AVG(`DRI or Pig Iron (%)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`DRI or Pig Iron (%)`) FROM steel1), 4)))-3
) AS kurtosis_DRI_or_PigIron_percent,
(
(SUM(POWER(`New DRI or Pig Iron (%)`- (SELECT AVG(`New DRI or Pig Iron (%)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`New DRI or Pig Iron (%)`) FROM Steel1), 4)))-3
) AS kurtosis_NewDRI_or_PigIron_percent,
(
(SUM(POWER(`Phosphorus (%)`- (SELECT AVG(`Phosphorus (%)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Phosphorus (%)`) FROM Steel1), 4)))-3
) AS kurtosis_Phosphorus_percent,
(
(SUM(POWER(`Carbon (%)`- (SELECT AVG(`Carbon (%)`) FROM Steel1), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Carbon (%)`) FROM Steel1), 4)))-3
) AS kurtosis_Carbon_percent
FROM Steel1;

################## Handling Duplicates #########################

####Count duplicates
SELECT `Grade of Steel`,`Automotive application`,COUNT(*) as duplicate_count
FROM Steel1
GROUP BY `Grade of Steel`,`Automotive application`
HAVING COUNT(*) > 1;

############################## Drop duplicates ####################################
############## Method-1

CREATE TABLE temp_Steel1 AS
SELECT DISTINCT *
FROM Steel1;

TRUNCATE TABLE steel1;

INSERT INTO steel1
SELECT * FROM temp_steel1;



################# Method-2

With duplicates AS (select `Grade of Steel`, Row_Number() over (partition by `Automotive application`,
`Scrap Steel (%)`,`DRI or Pig Iron (%)`,`Iron Ore (%)`,`Phosphorus (%)`,`Carbon (%)`,`Melting Time (EAF)`,`Production Volume`,
`Yield`,`BF Stage Cycle Time`,`EAF Stage Cycle Time`,`LRF Stage Cycle Time`,`Total Cycle Time`,`BF Electricity (kWh)`,
`EAF Electricity (kWh)`,`LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,`Original Cost per Ton`,`New Scrap Steel (%)`,
`New DRI or Pig Iron (%)`,`New Iron Ore (%)`,`New Electricity Consumption (kWh) Total`,`BF Electricity (kWh) (New)`,
`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,`Estimated Cost per Ton ($)`
ORDER BY `Grade of steel`) AS row_num From steel1)
DELETE From steel1 WHERE `Grade of Steel` IN ( select `Grade of Steel` From duplicates Where row_num > 1);

Select * from Steel1;

################  Outliers  #################

WITH z_scores AS (
    SELECT 
`Grade of steel`,`Automotive application`,
`Scrap Steel (%)`,`DRI or Pig Iron (%)`,`Iron Ore (%)`,`Phosphorus (%)`,`Carbon (%)`,`Melting Time (EAF)`,`Production Volume`,
`Yield`,`BF Stage Cycle Time`,`EAF Stage Cycle Time`,`LRF Stage Cycle Time`,`Total Cycle Time`,`BF Electricity (kWh)`,
`EAF Electricity (kWh)`,`LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,`Original Cost per Ton`,`New Scrap Steel (%)`,
`New DRI or Pig Iron (%)`,`New Iron Ore (%)`,`New Electricity Consumption (kWh) Total`,`BF Electricity (kWh) (New)`,
`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,`Estimated Cost per Ton ($)`,

-- Calculate z-scores for each numeric column
(`Scrap Steel (%)` - AVG(`Scrap Steel (%)`) OVER()) / STDDEV(`Scrap Steel (%)`) OVER() AS Scrap_Steel_zscore,
(`DRI or Pig Iron (%)` - AVG(`DRI or Pig Iron (%)`) OVER()) / STDDEV(`DRI or Pig Iron (%)`) OVER() AS DRI_or_Pig_Iron_zscore,
(`Iron Ore (%)` - AVG(`Iron Ore (%)`) OVER()) / STDDEV(`Iron Ore (%)`) OVER() AS Iron_Ore_zscore,
(`Phosphorus (%)` - AVG(`Phosphorus (%)`) OVER()) / STDDEV(`Phosphorus (%)`) OVER() AS Phosphorus_zscore,
(`Carbon (%)` - AVG(`Carbon (%)`) OVER()) / STDDEV(`Carbon (%)`) OVER() AS Carbon_zscore,
(`BF Electricity (kWh)` - AVG(`BF Electricity (kWh)`) OVER()) / STDDEV(`BF Electricity (kWh)`) OVER() AS BF_Electricity_kWh_zscore,
(`EAF Electricity (kWh)` - AVG(`EAF Electricity (kWh)`) OVER()) / STDDEV(`EAF Electricity (kWh)`) OVER() AS EAF_Electricity_kWh_zscore,
(`LRF Electricity (kWh)` - AVG(`LRF Electricity (kWh)`) OVER()) / STDDEV(`LRF Electricity (kWh)`) OVER() AS LRF_Electricity_kWh_zscore,
(`Total Electricity Consumption (kWh)` - AVG(`Total Electricity Consumption (kWh)`) OVER()) / STDDEV(`Total Electricity Consumption (kWh)`) OVER() AS Total_Electricity_Consumption_kWh_zscore,
(`New Scrap Steel (%)` - AVG(`New Scrap Steel (%)`) OVER()) / STDDEV(`New Scrap Steel (%)`) OVER() AS New_Scrap_Steel_zscore,
(`New DRI or Pig Iron (%)` - AVG(`New DRI or Pig Iron (%)`) OVER()) / STDDEV(`New DRI or Pig Iron (%)`) OVER() AS NewDRI_or_Pig_Iron_zscore,
(`New Iron Ore (%)` - AVG(`New Iron Ore (%)`) OVER()) / STDDEV(`New Iron Ore (%)`) OVER() AS New_Iron_Ore_zscore,
(`New Electricity Consumption (kWh) Total` - AVG(`New Electricity Consumption (kWh) Total`) OVER()) / STDDEV(`New Electricity Consumption (kWh) Total`) OVER() AS New_Electricity_Consumption_kWh_Total_zscore,
(`BF Electricity (kWh) (New)` - AVG(`BF Electricity (kWh) (New)`) OVER()) / STDDEV(`BF Electricity (kWh) (New)`) OVER() AS BF_Electricity_kWh_New_zscore,
(`EAF Electricity (kWh) (New)` - AVG(`EAF Electricity (kWh) (New)`) OVER()) / STDDEV(`EAF Electricity (kWh) (New)`) OVER() AS EAF_Electricity_kWh_New_zscore,
(`LRF Electricity (kWh) (New)` - AVG(`LRF Electricity (kWh) (New)`) OVER()) / STDDEV(`LRF Electricity (kWh) (New)`) OVER() AS LRF_Electricity_kWh_New_zscore

        -- Repeat for other numerical columns as needed
        -- Add z-scores for other columns here
    FROM steel1
)
-- Select rows where any z-score is greater than 3 (or any threshold you choose)
SELECT *
FROM z_scores
WHERE 
    ABS(Scrap_Steel_zscore) > 3
    OR ABS(DRI_or_Pig_Iron_zscore) > 3
    OR ABS(Iron_Ore_zscore) > 3 
    OR ABS(Phosphorus_zscore) > 3
    OR ABS(Carbon_zscore) > 3 
    OR ABS(BF_Electricity_kWh_zscore) > 3
    OR ABS(EAF_Electricity_kWh_zscore) > 3
    OR ABS(LRF_Electricity_kWh_zscore) > 3
    OR ABS(Total_Electricity_Consumption_kWh_zscore) > 3 
    OR ABS(New_Scrap_Steel_zscore) > 3
    OR ABS(NewDRI_or_Pig_Iron_zscore) > 3
    OR ABS(NEW_Iron_Ore_zscore) > 3
    OR ABS(New_Electricity_Consumption_kWh_Total_zscore) > 3 
    OR ABS(BF_Electricity_kWh_New_zscore) > 3
    OR ABS(EAF_Electricity_kWh_New_zscore) > 3
    OR ABS(LRF_Electricity_kWh_New_zscore) > 3;

############# ZERO & near Zero VARIANCE Features ########################

-- Calculate variance for each numerical column
SELECT
    'Grade of steel',
    VAR_SAMP(`Grade of steel`) AS Variance_Grade_Steel
FROM Steel1
UNION ALL
SELECT
    'Automotive application',
    VAR_SAMP('Automotive application') AS Variance_Automotive_application
FROM Steel1
UNION ALL
SELECT
    'Scrap Steel (%)',
    VAR_SAMP('Scrap Steel (%)') AS Variance_Scrap_Steel
FROM Steel1
UNION ALL
SELECT
    'DRI or Pig Iron (%)',
    VAR_SAMP('DRI or Pig Iron (%)') AS Variance_DRI_or_Pig_Iron
FROM Steel1
UNION ALL
SELECT
    'Iron Ore (%)',
    VAR_SAMP('Iron Ore (%)') AS Variance_Iron_Ore
FROM Steel1
UNION ALL
SELECT
    'Phosphorus (%)',
    VAR_SAMP('Phosphorus (%)') AS Variance_Phosphorus
FROM Steel1
UNION ALL
SELECT
    'Carbon (%)',
    VAR_SAMP('Carbon (%)') AS Variance_Carbon
FROM Steel1
UNION ALL
SELECT
    'Melting Time (EAF)',
    VAR_SAMP('Melting Time (EAF)') AS Variance_Melting_Time_EAF
FROM Steel1
UNION ALL
SELECT
    'Production Volume',
    VAR_SAMP( 'Production Volume') AS Variance_Production_Volume
FROM Steel1
UNION ALL
SELECT
    'Yield',
    VAR_SAMP(`Yield`) AS Variance_Yield
FROM Steel1
UNION ALL
SELECT
    'BF Stage Cycle Time',
    VAR_SAMP('BF Stage Cycle Time') AS Variance_BF_Stage_Cycle_Time
FROM Steel1
UNION ALL
SELECT
    'EAF Stage Cycle Time',
    VAR_SAMP('EAF Stage Cycle Time') AS Variance_EAF_Stage_Cycle_Time
FROM Steel1
UNION ALL
SELECT
    'LRF Stage Cycle Time',
    VAR_SAMP('LRF Stage Cycle Time') AS Variance_LRF_Stage_Cycle_Time
FROM Steel1
UNION ALL
SELECT
    'Total Cycle Time',
    VAR_SAMP('Total Cycle Time') AS Variance_Total_Cycle_Time
FROM Steel1
UNION ALL
SELECT
    'BF Electricity (kWh)',
    VAR_SAMP('BF Electricity (kWh)') AS Variance_BF_Electricity_kWh
FROM Steel1
UNION ALL
SELECT
    'EAF Electricity (kWh)',
    VAR_SAMP('EAF Electricity (kWh)') AS Variance_EAF_Electricity_kWh
FROM steel1
UNION ALL
SELECT
    'LRF Electricity (kWh)',
    VAR_SAMP('EAF Electricity (kWh)') AS Variance_LRF_Electricity_kWh
FROM Steel1
UNION ALL
SELECT
    'Total Electricity Consumption (kWh)',
    VAR_SAMP('Total Electricity Consumption (kWh)') AS Variance_Total_Electricity_Consumption_kWh
FROM Steel1
UNION ALL
SELECT
    'Original Cost per Ton',
    VAR_SAMP('Original Cost per Ton') AS Variance_Original_Cost_per_Ton
FROM Steel1
UNION ALL
SELECT
    'New Scrap Steel (%)',
    VAR_SAMP('New Scrap Steel (%)') AS Variance_New_Scrap_Steel
FROM Steel1
UNION ALL
SELECT
    'New DRI or Pig Iron (%)',
    VAR_SAMP('New DRI or Pig Iron (%)') AS Variance_New_DRI_or_Pig_Iron
FROM Steel1
UNION ALL
SELECT
    'New Iron Ore (%)',
    VAR_SAMP('New Iron Ore (%)') AS Variance_New_Iron_Ore
FROM Steel1
UNION ALL
SELECT
    'New Electricity Consumption (kWh) Total',
    VAR_SAMP(`New Electricity Consumption (kWh) Total`) AS Variance_New_Electricity_Consumption_kWh_Total
FROM Steel1
UNION ALL
SELECT
    'BF Electricity (kWh) (New)',
    VAR_SAMP('BF Electricity (kWh) (New)') AS Variance_BF_Electricity_kWh_New
FROM Steel1
UNION ALL
SELECT
    'EAF Electricity (kWh) (New)',
    VAR_SAMP('EAF Electricity (kWh) (New)') As Variance_EAF_Electricity_kWh_New
FROM Steel1
UNION ALL
SELECT
    'LRF Electricity (kWh) (New)',
    VAR_SAMP('LRF Electricity (kWh) (New)') AS Variance_LRF_Electricity_kWh_New
FROM Steel1
UNION ALL
SELECT
    'Estimated Cost per Ton ($)',
    VAR_SAMP('Estimated Cost per Ton ($)') AS Variance_Estimated_Cost_per_Ton
FROM steel1;

######################## Missing Values ###################################

SELECT
    'Grade of steel' AS Column_Name,
    COUNT(*) - COUNT('Grade of steel') AS MissingValues_Grade_of_steel
FROM steel1
UNION ALL
SELECT
    'Automotive application',
    COUNT(*) - COUNT('Automotive application') AS MissingValues_Automotive_application
FROM steel1
UNION ALL
SELECT
    'Scrap Steel (%)',
    COUNT(*) - COUNT('Scrap Steel (%)') AS MissingValues_Scrap_Stee
FROM steel1
UNION ALL
SELECT
    'DRI or Pig Iron (%)',
    COUNT(*) - COUNT('DRI or Pig Iron (%)') AS MissingValues_DRI_or_Pig_Iron
FROM Steel1
UNION ALL
SELECT
    'Iron Ore (%)',
    COUNT(*) - COUNT('Iron Ore (%)') AS MissingValues_Iron_Ore
FROM Steel1
UNION ALL
SELECT
    'Phosphorus (%)',
    COUNT(*) - COUNT('Phosphorus (%)') AS MissingValues_Phosphorus
FROM Steel1
UNION ALL
SELECT
    'Carbon (%)',
    COUNT(*) - COUNT('Carbon (%)') AS MissingValues_Carbon
FROM Steel1
UNION ALL
SELECT
    'Melting Time (EAF)',
    COUNT(*) - COUNT('Melting Time (EAF)') AS MissingValues_Melting_Time_EAF
FROM steel1
UNION ALL
SELECT
    'Production Volume',
    COUNT(*) - COUNT('Production Volume') AS MissingValues_Production_Volume
FROM steel1
UNION ALL
SELECT
    'Yield',
    COUNT(*) - COUNT('Yield') AS MissingValues_Yield
FROM Steel1
UNION ALL
SELECT
    'BF Stage Cycle Time',
    COUNT(*) - COUNT('BF Stage Cycle Time') AS MissingValues_BF_Stage_Cycle_Time
FROM Steel1
UNION ALL
SELECT
    'EAF Stage Cycle Time',
    COUNT(*) - COUNT('EAF Stage Cycle Time') AS MissingValues_EAF_Stage_Cycle_Time
FROM Steel1
UNION ALL
SELECT
    'LRF Stage Cycle Time',
    COUNT(*) - COUNT('LRF Stage Cycle Time') AS MissingValues_LRF_Stage_Cycle_Time
FROM Steel1
UNION ALL
SELECT
    'Total Cycle Time',
    COUNT(*) - COUNT('Total Cycle Time') AS MissingValues_Total_Cycle_Time
FROM steel1
UNION ALL
SELECT
    'BF Electricity (kWh)',
    COUNT(*) - COUNT('BF Electricity (kWh)') AS MissingValues_BF_Electricity_kWh
FROM Steel1
UNION ALL
SELECT
    'EAF Electricity (kWh)',
    COUNT(*) - COUNT('EAF Electricity (kWh)') AS MissingValues_EAF_Electricity_kWh
FROM Steel1
UNION ALL
SELECT
    'LRF Electricity (kWh)',
    COUNT(*) - COUNT('LRF Electricity (kWh)') AS MissingValues_LRF_Electricity_kWh
FROM Steel1
UNION ALL
SELECT
    'Total Electricity Consumption (kWh)',
    COUNT(*) - COUNT('Total Electricity Consumption (kWh)') AS MissingValues_Total_Electricity_Consumption_kWh
FROM Steel1
UNION ALL
SELECT
    'Original Cost per Ton',
    COUNT(*) - COUNT('Original Cost per Ton') As MissingValues_Original_Cost_per_Ton
FROM Steel1
UNION ALL
SELECT
    'New Scrap Steel (%)',
    COUNT(*) - COUNT('New Scrap Steel (%)') AS MissingValues_New_Scrap_Steel
FROM Steel1
UNION ALL
SELECT
    'New DRI or Pig Iron (%)',
    COUNT(*) - COUNT('New DRI or Pig Iron (%)') AS MissingValues_New_DRI_or_Pig_Iron
FROM Steel1
UNION ALL
SELECT
    'New Iron Ore (%)',
    COUNT(*) - COUNT('New Iron Ore (%)') AS MissingValues_New_Iron_Ore
FROM Steel1
UNION ALL
SELECT
    'New Electricity Consumption (kWh) Total',
    COUNT(*) - COUNT('New Electricity Consumption (kWh) Total') AS MissingValues_New_Electricity_Consumption_kWh_Total
FROM Steel1
UNION ALL
SELECT
    'BF Electricity (kWh) (New)',
    COUNT(*) - COUNT('BF Electricity (kWh) (New)') AS MissingValues_BfF_Electricity_kWh_New
FROM Steel1
UNION ALL
SELECT
    'EAF Electricity (kWh) (New)',
    COUNT(*) - COUNT('EAF Electricity (kWh) (New)') AS MissingValues_EAF_Electricity_kWh_New
FROM Steel1
UNION ALL
SELECT
    'LRF Electricity (kWh) (New)',
    COUNT(*) - COUNT('LRF Electricity (kWh) (New)') As MissingValues_LRF_Electricity_kWh_New
FROM Steel1
UNION ALL
SELECT
    'Estimated Cost per Ton ($)',
    COUNT(*) - COUNT('Estimated Cost per Ton ($)') AS MissingValues_Estimated_Cost_per_Ton
FROM Steel1;

################## Normalization ########################

-- Assuming Grade of steel and Automotive application together uniquely identify each row

use steel;
CREATE  table mtrl_scaled AS
SELECT
`Grade of Steel`,`Automotive application`,`Scrap Steel (%)`,`DRI or Pig Iron (%)`,`Iron Ore (%)`,
( `Scrap Steel (%)`- min_Scrap_Steel_percent) / (max_Scrap_Steel_percent - min_Scrap_Steel_percent) AS scaled_Scrap_Steel_percent,
( `DRI or Pig Iron (%)`- min_DRI_or_Pig_Iron_percent) / (max_DRI_or_Pig_Iron_percent - min_DRI_or_Pig_Iron_percent) AS scaled_DRI_or_Pig_Iron_percent,
( `Iron Ore (%)`- min_Iron_Ore_percent) / (max_Iron_Ore_percent - min_Iron_Ore_percent) AS scaled_Iron_Ore_percent,
( `Phosphorus (%)`- min_Phosphorus_percent) / (max_Phosphorus_percent - min_Phosphorus_percent) AS scaled_Phosphorus_percent,
( `Carbon (%)`- min_Carbon_percent) / (max_Carbon_percent - min_Carbon_percent) AS scaled_Carbon_percent
FROM (
SELECT
`Grade of Steel`,`Automotive application`,`Scrap Steel (%)`,`DRI or Pig Iron (%)`,`Iron Ore (%)`,`Phosphorus (%)`,`Carbon (%)`,
(SELECT MIN(`Scrap Steel (%)`) FROM Steel1) AS min_Scrap_Steel_percent,
(SELECT MAX(`Scrap Steel (%)`) FROM Steel1) AS max_Scrap_Steel_percent,
(SELECT MIN(`DRI or Pig Iron (%)`) FROM Steel1) AS min_DRI_or_Pig_Iron_percent,
(SELECT MAX(`DRI or Pig Iron (%)`) FROM Steel1) AS max_DRI_or_Pig_Iron_percent,
(SELECT MIN(`Iron Ore (%)`) FROM Steel1) AS min_Iron_Ore_percent,
(SELECT MAX(`Iron Ore (%)`) FROM Steel1) AS max_Iron_Ore_percent,
(SELECT MIN(`Phosphorus (%)`) FROM Steel1) AS min_Phosphorus_percent,
(SELECT MAX(`Phosphorus (%)`) FROM Steel1) AS max_Phosphorus_percent,
(SELECT MIN(`Carbon (%)`) FROM Steel1) AS min_Carbon_percent,
(SELECT MAX(`Carbon (%)`) FROM Steel1) AS max_Carbon_percent
FROM Steel1
) AS scaled_data;

CREATE  table materials_scaled AS
SELECT `Phosphorus (%)`,`Carbon (%)`,`Melting Time (EAF)`,`Production Volume`,
`Yield`, `BF Stage Cycle Time`,`EAF Stage Cycle Time`,`LRF Stage Cycle Time`,`Total Cycle Time`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`,
`LRF Electricity (kWh)`,
(`Melting Time (EAF)` - min_Melting_Time_EAF) / (max_Melting_Time_EAF - min_Melting_Time_EAF) AS scaled_Melting_Time_EAF,
( `Production Volume`- min_Production_Volume) / (max_Production_Volume - min_Production_Volume) AS scaled_Production_Volume,
(`Yield`- min_Yield) / (max_Yield - min_Yield) AS scaled_Yield,
( `BF Stage Cycle Time`- min_BF_Stage_Cycle_Time) / (max_BF_Stage_Cycle_Time - min_BF_Stage_Cycle_Time) AS scaled_BF_Stage_Cycle_Time,
( `EAF Stage Cycle Time`- min_EAF_Stage_Cycle_Time) / (max_EAF_Stage_Cycle_Time - min_EAF_Stage_Cycle_Time) AS scaled_EAF_Stage_Cycle_Time,
( `LRF Stage Cycle Time`- min_LRF_Stage_Cycle_Time) / (max_LRF_Stage_Cycle_Time - min_LRF_Stage_Cycle_Time) AS scaled_LRF_Stage_Cycle_Time,
( `Total Cycle Time`- min_Total_Cycle_Time) / (max_Total_Cycle_Time - min_Total_Cycle_Time) AS scaled_Total_Cycle_Time,
( `BF Electricity (kWh)`- min_BF_Electricity_kWh) / (max_BF_Electricity_kWh - min_BF_Electricity_kWh) AS scaled_BF_Electricity_kWh,
( `EAF Electricity (kWh)`- min_EAF_Electricity_kWh) / (max_EAF_Electricity_kWh - min_EAF_Electricity_kWh) AS scaled_EAF_Electricity_kWh,
( `LRF Electricity (kWh)`- min_LRF_Electricity_kWh) / (max_LRF_Electricity_kWh - min_LRF_Electricity_kWh) AS scaled_LRF_Electricity_kWh
FROM (
SELECT
`Phosphorus (%)`,`Carbon (%)`,`Melting Time (EAF)`,`Production Volume`,
`Yield`, `BF Stage Cycle Time`,`EAF Stage Cycle Time`,`LRF Stage Cycle Time`,`Total Cycle Time`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`,
`LRF Electricity (kWh)`,
(SELECT MIN(`Melting Time (EAF)`) FROM Steel1) AS min_Melting_Time_EAF,
(SELECT MAX(`Melting Time (EAF)`) FROM Steel1) AS max_Melting_Time_EAF,
(SELECT MIN(`Production Volume`) FROM Steel1) AS min_Production_Volume,
(SELECT MAX(`Production Volume`) FROM Steel1) AS max_Production_Volume,
(SELECT MIN(`Yield`) FROM Steel1) AS min_Yield,
(SELECT MAX(`Yield`) FROM Steel1) AS max_Yield,
(SELECT MIN(`BF Stage Cycle Time`) FROM Steel1) AS min_BF_Stage_Cycle_Time,
(SELECT MAX(`BF Stage Cycle Time`) FROM Steel1) AS max_BF_Stage_Cycle_Time,
(SELECT MIN(`EAF Stage Cycle Time`) FROM Steel1) AS min_EAF_Stage_Cycle_Time,
(SELECT MAX(`EAF Stage Cycle Time`) FROM Steel1) AS max_EAF_Stage_Cycle_Time,
(SELECT MIN(`LRF Stage Cycle Time`) FROM Steel1) AS min_LRF_Stage_Cycle_Time,
(SELECT MAX(`LRF Stage Cycle Time`) FROM Steel1) AS max_LRF_Stage_Cycle_Time,
(SELECT MIN(`Total Cycle Time`) FROM Steel1) AS min_Total_Cycle_Time,
(SELECT MAX(`Total Cycle Time`) FROM Steel1) AS max_Total_Cycle_Time,
(SELECT MIN(`BF Electricity (kWh)`) FROM Steel1) AS min_BF_Electricity_kWh,
(SELECT MAX(`BF Electricity (kWh)`) FROM Steel1) AS max_BF_Electricity_kWh,
(SELECT MIN(`EAF Electricity (kWh)`) FROM Steel1) AS min_EAF_Electricity_kWh,
(SELECT MAX(`EAF Electricity (kWh)`) FROM Steel1) AS max_EAF_Electricity_kWh,
(SELECT MIN(`LRF Electricity (kWh)`) FROM Steel1) AS min_LRF_Electricity_kWh,
(SELECT MAX(`LRF Electricity (kWh)`) FROM Steel1) AS max_LRF_Electricity_kWh
FROM Steel1
) AS scaled_data;
select * from materials_scaled;

drop table materials_scaled;
CREATE TABLE materials AS
SELECT
`EAF Electricity (kWh)`,`LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,`New Scrap Steel (%)`,`New DRI or Pig Iron (%)`,
(`Total Electricity Consumption (kWh)`- min_Total_Electricity_Consumption_kWh) / (max_Total_Electricity_Consumption_kWh - min_Total_Electricity_Consumption_kWh) AS scaled_Total_Electricity_Consumption_kWh,
(`New Scrap Steel (%)`- min_New_Scrap_Steel) / (max_New_Scrap_Steel - min_New_Scrap_Steel) AS scaled_New_Scrap_Steel,
(`New DRI or Pig Iron (%)`- min_New_DRI_or_Pig_Iron) / (max_New_DRI_or_Pig_Iron - min_New_DRI_or_Pig_Iron) AS scaled_New_DRI_or_Pig_Iron,
(`New Iron Ore (%)`- min_New_Iron_Ore) / (max_New_Iron_Ore - min_New_Iron_Ore) AS scaled_New_Iron_Ore,
(`New Electricity Consumption (kWh) Total`- min_New_Electricity_Consumption_kWh_Total) / (max_New_Electricity_Consumption_kWh_Total - min_New_Electricity_Consumption_kWh_Total) AS scaled_New_Electricity_Consumption_kWh_Total
FROM (
SELECT
`EAF Electricity (kWh)`,`LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,`New Scrap Steel (%)`,`New DRI or Pig Iron (%)`,
`New Iron Ore (%)`,`New Electricity Consumption (kWh) Total`,
(SELECT MIN(`Total Electricity Consumption (kWh)`) FROM Steel1) AS min_Total_Electricity_Consumption_kWh,
(SELECT MAX(`Total Electricity Consumption (kWh)`) FROM Steel1) AS max_Total_Electricity_Consumption_kWh,
(SELECT MIN(`New Scrap Steel (%)`) FROM Steel1) AS min_New_Scrap_Steel,
(SELECT MAX(`New Scrap Steel (%)`) FROM Steel1) AS max_New_Scrap_Steel,
(SELECT MIN(`New DRI or Pig Iron (%)`) FROM Steel1) AS min_New_DRI_or_Pig_Iron,
(SELECT MAX(`New DRI or Pig Iron (%)`) FROM Steel1) AS max_New_DRI_or_Pig_Iron,
(SELECT MIN(`New Iron Ore (%)`) FROM Steel1) AS min_New_Iron_Ore,
(SELECT MAX(`New Iron Ore (%)`) FROM Steel1) AS max_New_Iron_Ore,
(SELECT MIN(`New Electricity Consumption (kWh) Total`) FROM Steel1) AS min_New_Electricity_Consumption_kWh_Total,
(SELECT MAX(`New Electricity Consumption (kWh) Total`) FROM Steel1) AS max_New_Electricity_Consumption_kWh_Total
FROM Steel1
) AS scaled_data;


CREATE  table scaled AS
SELECT
`New Iron Ore (%)`,`New Electricity Consumption (kWh) Total`,`BF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,
 (`BF Electricity (kWh) (New)`- min_BF_Electricity_kWh_New) / (max_BF_Electricity_kWh_New - min_BF_Electricity_kWh_New) AS scaled_BF_Electricity_kWh_New,
(`EAF Electricity (kWh) (New)`- min_EAF_Electricity_kWh_New) / (max_EAF_Electricity_kWh_New - min_EAF_Electricity_kWh_New) AS scaled_EAF_Electricity_kWh_New,
(`LRF Electricity (kWh) (New)`- min_LRF_Electricity_kWh_New) / (max_LRF_Electricity_kWh_New - min_LRF_Electricity_kWh_New) AS scaled_LRF_Electricity_kWh_New
FROM (
SELECT
`New Iron Ore (%)`,`New Electricity Consumption (kWh) Total`,`BF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,
(SELECT MIN(`BF Electricity (kWh) (New)`) FROM Steel1) AS min_BF_Electricity_kWh_New,
(SELECT MAX(`BF Electricity (kWh) (New)`) FROM Steel1) AS max_BF_Electricity_kWh_New,
(SELECT MIN(`EAF Electricity (kWh) (New)`) FROM Steel1) AS min_EAF_Electricity_kWh_New,
(SELECT MAX(`EAF Electricity (kWh) (New)`) FROM Steel1) AS max_EAF_Electricity_kWh_New,
(SELECT MIN(`LRF Electricity (kWh) (New)`) FROM Steel1) AS min_LRF_Electricity_kWh_New,
(SELECT MAX(`LRF Electricity (kWh) (New)`) FROM Steel1) AS max_LRF_Electricity_kWh_New
FROM Steel1
) AS scaled_data;


################################### Winsorization ###############################

##########It works only in postgradesql




##################################### Discretization/Binning/Grouping rawmaterials ##############################################
create database normalization;
use normalization;
select * from nrmfresh;
SELECT `Grade of steel`,`Automotive application`,`Scrap Steel (%)`,
-- Discretized columns using CASE statements
    CASE 
        WHEN `Scrap Steel (%)` < 0.25 THEN '0-0.25%'
        WHEN `Scrap Steel (%)` < 0.5 THEN '0.25-0.5%'
        WHEN `Scrap Steel (%)` < 0.75 THEN '0.5-0.75%'
        ELSE '0.75% & above'
    END AS `Discretized Scrap Steel`
    from nrmfresh;
select `Grade of steel`,`Automotive application`,`DRI or Pig Iron (%)`,
CASE 
        WHEN `DRI or Pig Iron (%)` < 0.25 THEN '0-0.25%'
        WHEN `DRI or Pig Iron (%)` < 0.5 THEN '0.25-0.5%'
        WHEN `DRI or Pig Iron (%)` < 0.75 THEN '0.5-0.75%'
        ELSE '0.75% & above'
    END AS `Discretized DRI or Pig Iron`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`Iron Ore (%)`,
CASE
		WHEN `Iron Ore (%)` < 0.25 THEN '0-0.25%'
        WHEN `Iron Ore (%)` < 0.5 THEN '0.25-0.5%'
        WHEN `Iron Ore (%)` < 0.75 THEN '0.5-0.75%'
        ELSE '0.75% & above'
    END AS `Discretized Iron Ore`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`Phosphorus (%)`,
CASE
		WHEN `Phosphorus (%)` < 0.25 THEN '0-0.25%'
        WHEN `Phosphorus (%)` < 0.5 THEN '0.25-0.5%'
        WHEN `Phosphorus (%)` < 0.75 THEN '0.5-0.75%'
        ELSE '0.75% & above'
    END AS `Discretized Phosphorus`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`Carbon (%)`,
CASE
		WHEN `Carbon (%)` < 0.25 THEN '0-0.25%'
        WHEN `Carbon (%)` < 0.5 THEN '0.25-0.5%'
        WHEN `Carbon (%)` < 0.75 THEN '0.5-0.75%'
        ELSE '0.75% & above'
    END AS `Discretized Carbon`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`Melting Time (EAF)`,
CASE
		WHEN `Melting Time (EAF)` < 0.25 THEN '0-0.25'
        WHEN `Melting Time (EAF)` < 0.5 THEN '0.25-0.5'
        WHEN `Melting Time (EAF)` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized Melting Time (EAF)`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`Production Volume`,
CASE
		WHEN `Production Volume` < 0 THEN '-60-0 tons'
        WHEN `Production Volume` < 7 THEN '0- 7 tons'
        WHEN `Production Volume` < 15 THEN '7-15 tons'
        ELSE '5 tons & above'
    END AS `Discretized Production Volume`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`Yield`,
CASE
		WHEN `Yield` < 0.25 THEN '0-0.25%'
        WHEN `Yield` < 0.5 THEN '0.25-0.5%'
        WHEN `Yield` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized Yield`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`BF Stage Cycle Time`,
CASE
		WHEN `BF Stage Cycle Time` < 0.25 THEN '0-0.25'
        WHEN `BF Stage Cycle Time` < 0.5 THEN '0.25-0.5'
        WHEN `BF Stage Cycle Time` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized BF Stage Cycle Time`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`EAF Stage Cycle Time`,
CASE
		WHEN `EAF Stage Cycle Time` < 0.25 THEN '0-0.25'
        WHEN `EAF Stage Cycle Time` < 0.5 THEN '0.25-0.5'
        WHEN `EAF Stage Cycle Time` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized EAF Stage Cycle Time`
from nrmfresh;

select `Grade of steel`,`Automotive application`,`EAF Electricity (kWh)`,
CASE
		WHEN `EAF Electricity (kWh)` < 0.25 THEN '0-0.25'
        WHEN `EAF Electricity (kWh)` < 0.5 THEN '0.25-0.5'
        WHEN `EAF Electricity (kWh)` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized EAF Electricity (kWh)`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`LRF Electricity (kWh)`,
CASE
		WHEN `LRF Electricity (kWh)` < 0.25 THEN '0-0.25'
        WHEN `LRF Electricity (kWh)` < 0.5 THEN '0.25-0.5'
        WHEN `LRF Electricity (kWh)` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized LRF Electricity (kWh)`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`Total Electricity Consumption (kWh)`,
CASE
		WHEN `Total Electricity Consumption (kWh)` < 0.25 THEN '0-0.25'
        WHEN `Total Electricity Consumption (kWh)` < 0.5 THEN '0.25-0.5'
        WHEN `Total Electricity Consumption (kWh)` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized Total Electricity Consumption (kWh)`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`New Scrap Steel (%)`,
CASE 
        WHEN `New Scrap Steel (%)` < 30 THEN '0-30%'
        WHEN `New Scrap Steel (%)` < 0.5 THEN '0.25-0.5'
        WHEN `New Scrap Steel (%)` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized New Scrap Steel`
from nrmfresh;

select `Grade of steel`,`Automotive application`,`New DRI or Pig Iron (%)`,
CASE 
        WHEN `New DRI or Pig Iron (%)` < 0.25 THEN '0-0.25%'
        WHEN `New DRI or Pig Iron (%)` < 0.5 THEN '0.25-0.5'
        WHEN `New DRI or Pig Iron (%)` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized New DRI or Pig Iron`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`New Iron Ore (%)`,
CASE
		WHEN `New Iron Ore (%)` < 0.25 THEN '0-0.25%'
        WHEN `New Iron Ore (%)` < 0.5 THEN '0.25-0.5'
        WHEN `New Iron Ore (%)` < 0.75 THEN '0.5-0.75%'
        ELSE '0.75% & above'
    END AS `Discretized New Iron Ore`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`New Electricity Consumption (kWh) Total`,
CASE
		WHEN `New Electricity Consumption (kWh) Total` < 0 THEN '-20- 0 hours'
        WHEN `New Electricity Consumption (kWh) Total` < 1 THEN '0 - 1 hours'
        ELSE '1 hours and above'
    END AS `Discretized New Electricity Consumption (kWh) Total`
from nrmfresh;
select `Grade of steel`,`Automotive application`,`BF Electricity (kWh) (New)`,
CASE
		WHEN `BF Electricity (kWh) (New)` < 0.25 THEN '0-0.25'
        WHEN `BF Electricity (kWh) (New)` < 0.5 THEN '0.25-0.5'
        WHEN `BF Electricity (kWh) (New)` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized BF Electricity (kWh) (New)`
fRom nrmfresh;
select `Grade of steel`,`Automotive application`,`EAF Electricity (kWh) (New)`,
CASE
		WHEN `EAF Electricity (kWh) (New)` < 0.25 THEN '0-0.25'
        WHEN `EAF Electricity (kWh) (New)` < 0.5 THEN '0.25-0.5'
        WHEN `EAF Electricity (kWh) (New)` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized EAF Electricity (kWh) (New)`
FROM nrmfresh;

select `Grade of steel`,`Automotive application`,`LRF Electricity (kWh) (New)`,
CASE
		WHEN `LRF Electricity (kWh) (New)` < 0.25 THEN '0-0.25'
        WHEN `LRF Electricity (kWh) (New)` < 0.5 THEN '0.25-0.5'
        WHEN `LRF Electricity (kWh) (New)` < 0.75 THEN '0.5-0.75'
        ELSE '0.75 & above'
    END AS `Discretized LRF Electricity (kWh) (New)`
FRom nrmfresh;



SELECT * FROM rawmaterials;


######################## Dummy Variable Creation steel1 ######################################

########### Method 1 ###############
use steel;
SELECT
    `Grade of steel`,`Automotive application`,
    CASE WHEN `Original Cost Per Ton` IS NOT NULL THEN 1 ELSE 0 END AS `Original_cost_dummy`,
    CASE WHEN `Estimated cost per Ton ($)` IS NOT NULL THEN 1 ELSE 0 END AS `Estimated_cost_dummy`
FROM
   steel1;
   


    
##################### BUSINESS MOMENTS AFTER EDA PREPROCESSING ################################

create database normalization;
use normalization;

###################### First Moment Business Decision / Measures of Central Tendency #############################

Select * from nrmfresh;
###  Mean  ###

SELECT AVG(`New Scrap Steel (%)`) AS mean_New_scrap_steel_percent, AVG(`BF Electricity (kWh)`) AS mean_BF_Electricity_kWh,
AVG(`EAF Electricity (kWh)`) AS mean_EAF_Electricity_kWh,AVG(`LRF Electricity (kWh)`) AS mean_LRF_Electricity_kWh,
AVG(`Total Electricity Consumption (kWh)`) AS mean_Total_Electricity_Consumption_kWh,AVG(`New Electricity Consumption (kWh) Total`) AS mean_New_Electricity_Consumption_kWh_Total,
AVG(`bF Electricity (kWh) (New)`) AS mean_BF_Electricity_kWh_New,AVG(`EAF Electricity (kWh) (New)`) AS mean_EAF_Electricity_kWh_New,
AVG(`LRF Electricity (kWh) (New)`) AS mean_LRF_Electricity_kWh_New,AVG(`Scrap Steel (%)`) AS mean_scrap_steel_percent,AVG(`Iron Ore (%)`) AS mean_Iron_Ore_percent,
AVG(`New Iron Ore (%)`) AS mean_New_Iron_Ore_percent,
AVG(`New DRI or Pig Iron (%)`) AS mean_NewDRI_or_Pig_Iron_percent,AVG(`DRI or Pig Iron (%)`) AS mean_DRI_or_Pig_Iron_percent,AVG(`carbon (%)`) AS mean_carbon_percent,
AVG(`Phosphorus (%)`) AS mean_Phosphorus_percent
FROM nrmfresh;


###  Median  ###

SELECT `New Scrap Steel (%)` AS median_New_scrap_steel_percent,`BF Electricity (kWh)` AS median_BF_Electricity_kWh,
`EAF Electricity (kWh)` AS median_EAF_Electricity_kWh,`LRF Electricity (kWh)` AS median_LRF_Electricity_kWh,
`Total Electricity Consumption (kWh)` AS median_Total_Electricity_Consumption_kWh,`New Electricity Consumption (kWh) Total` AS median_New_Electricity_Consumption_kWh_Total,
`bF Electricity (kWh) (New)` AS median_BF_Electricity_kWh_New,`EAF Electricity (kWh) (New)` AS median_EAF_Electricity_kWh_New,
`LRF Electricity (kWh) (New)` AS median_LRF_Electricity_kWh_New,`Scrap Steel (%)` AS median_scrap_steel_percent,`Iron Ore (%)` AS median_Iron_Ore_percent,`New Iron Ore (%)` AS median_New_Iron_Ore_percent,
`New DRI or Pig Iron (%)` AS median_NewDRI_or_Pig_Iron_percent,`DRI or Pig Iron (%)` AS median_DRI_or_Pig_Iron_percent,`carbon (%)` AS median_carbon_percent,
`Phosphorus (%)` AS median_Phosphorus_percent
FROM (
SELECT `New Scrap Steel (%)`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`, `LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,
`New Electricity Consumption (kWh) Total`,`bF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,
`Scrap Steel (%)`,`Iron Ore (%)`,`New Iron Ore (%)`,`New DRI or Pig Iron (%)`,`DRI or Pig Iron (%)`,
`carbon (%)`,`Phosphorus (%)`,
ROW_NUMBER() OVER (ORDER BY `New Scrap Steel (%)`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`,`LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,
`New Electricity Consumption (kWh) Total`,`bF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,
`Scrap Steel (%)`,`Iron Ore (%)`,`New Iron Ore (%)`,`New DRI or Pig Iron (%)`,`DRI or Pig Iron (%)`,
`carbon (%)`,`Phosphorus (%)`) AS row_num,
COUNT(*) OVER () AS total_count
FROM nrmfresh
) AS subquery
WHERE row_num = (total_count + 1) / 2 OR row_num = (total_count + 2) / 2;


### Mode ###

SELECT `New Scrap Steel (%)` AS mode_New_scrap_steel_percent,`BF Electricity (kWh)` AS mode_BF_Electricity_kWh,
`EAF Electricity (kWh)` AS mode_EAF_Electricity_kWh,`LRF Electricity (kWh)` AS mode_LRF_Electricity_kWh,
`Total Electricity Consumption (kWh)` AS mode_Total_Electricity_Consumption_kWh,`New Electricity Consumption (kWh) Total` AS mode_New_Electricity_Consumption_kWh_Total,
`bF Electricity (kWh) (New)` AS mode_BF_Electricity_kWh_New,`EAF Electricity (kWh) (New)` AS mode_EAF_Electricity_kWh_New,
`LRF Electricity (kWh) (New)` AS mode_LRF_Electricity_kWh_New,`Scrap Steel (%)` AS mode_scrap_steel_percent,`Iron Ore (%)` AS mode_Iron_Ore_percent,`New Iron Ore (%)` AS mode_New_Iron_Ore_percent,
`New DRI or Pig Iron (%)` AS mode_NewDRI_or_Pig_Iron_percent,`DRI or Pig Iron (%)` AS mode_DRI_or_Pig_Iron_percent,`carbon (%)` AS mode_carbon_percent,
`Phosphorus (%)` AS mode_Phosphorus_percent
FROM (
SELECT `New Scrap Steel (%)`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`, `LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,
`New Electricity Consumption (kWh) Total`,`bF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,
`Scrap Steel (%)`,`Iron Ore (%)`,`New Iron Ore (%)`,`New DRI or Pig Iron (%)`,`DRI or Pig Iron (%)`,
`carbon (%)`,`Phosphorus (%)`, count(*) as frequency from nrmfresh
Group BY `New Scrap Steel (%)`,`BF Electricity (kWh)`,`EAF Electricity (kWh)`,`LRF Electricity (kWh)`,`Total Electricity Consumption (kWh)`,
`New Electricity Consumption (kWh) Total`,`bF Electricity (kWh) (New)`,`EAF Electricity (kWh) (New)`,`LRF Electricity (kWh) (New)`,
`Scrap Steel (%)`,`Iron Ore (%)`,`New Iron Ore (%)`,`New DRI or Pig Iron (%)`,`DRI or Pig Iron (%)`,
`carbon (%)`,`Phosphorus (%)`
ORDER BY frequency DESC
LIMIT 1
) AS subquery;
###################### Second Moment Business Decision / Measures of Dispersion #############################

######### Variance #########


use normalization;
SELECT variance(`New Scrap Steel (%)`) AS variance_New_scrap_steel_percent,variance(`BF Electricity (kWh)`) AS variance_BF_Electricity_kWh,
variance(`EAF Electricity (kWh)`) AS variance_EAF_Electricity_kWh,variance(`LRF Electricity (kWh)`) AS variance_LRF_Electricity_kWh,
variance(`Total Electricity Consumption (kWh)`) AS variance_Total_Electricity_Consumption_kWh,variance(`New Electricity Consumption (kWh) Total`) AS variance_New_Electricity_Consumption_kWh_Total,
variance(`bF Electricity (kWh) (New)`) AS variance_BF_Electricity_kWh_New,variance(`EAF Electricity (kWh) (New)`) AS variance_EAF_Electricity_kWh_New,
variance(`LRF Electricity (kWh) (New)`) AS variance_LRF_Electricity_kWh_New,variance(`Scrap Steel (%)`) AS variance_scrap_steel_percent,variance(`Iron Ore (%)`) AS variance_Iron_Ore_percent,variance(`New Iron Ore (%)`) AS variance_New_Iron_Ore_percent,
variance(`New DRI or Pig Iron (%)`) AS variance_NewDRI_or_Pig_Iron_percent,variance(`DRI or Pig Iron (%)`) AS variance_DRI_or_Pig_Iron_percent,variance(`carbon (%)`) AS variance_carbon_percent,
variance(`Phosphorus (%)`) AS variance_Phosphorus_percent
FROM nrmfresh;

########## Standard Deviation ############

SELECT STDDEV(`New Scrap Steel (%)`) AS STDDEV_New_scrap_steel_percent,STDDEV(`BF Electricity (kWh)`) AS STDDEV_BF_Electricity_kWh,
STDDEV(`EAF Electricity (kWh)`) AS STDDEV_EAF_Electricity_kWh,STDDEV(`LRF Electricity (kWh)`) AS STDDEV_LRF_Electricity_kWh,
STDDEV(`Total Electricity Consumption (kWh)`) AS STDDEV_Total_Electricity_Consumption_kWh,STDDEV(`New Electricity Consumption (kWh) Total`) AS variance_New_Electricity_Consumption_kWh_Total,
STDDEV(`bF Electricity (kWh) (New)`) AS STDDEV_BF_Electricity_kWh_New,STDDEV(`EAF Electricity (kWh) (New)`) AS STDDEV_EAF_Electricity_kWh_New,
STDDEV(`LRF Electricity (kWh) (New)`) AS STDDEV_LRF_Electricity_kWh_New,STDDEV(`Scrap Steel (%)`) AS STDDEV_scrap_steel_percent,STDDEV(`Iron Ore (%)`) AS STDDEV_Iron_Ore_percent,STDDEV(`New Iron Ore (%)`) AS STDDEV_New_Iron_Ore_percent,
STDDEV(`New DRI or Pig Iron (%)`) AS STDDEV_NewDRI_or_Pig_Iron_percent,STDDEV(`DRI or Pig Iron (%)`) AS STDDEV_DRI_or_Pig_Iron_percent,STDDEV(`carbon (%)`) AS STDDEV_carbon_percent,
STDDEV(`Phosphorus (%)`) AS STDDEV_Phosphorus_percent
FROM nrmfresh;


############ Range ############

SELECT
MAX(`BF Electricity (kWh)`) - MIN(`BF Electricity (kWh)`) AS range_BF_Electricity_kWh,
MAX(`EAF Electricity (kWh)`) - MIN(`EAF Electricity (kWh)`) AS range_EAF_Electricity_kWh,
MAX(`LRF Electricity (kWh)`) - MIN(`LRF Electricity (kWh)`) AS range_LRF_Electricity_kWh,
MAX(`BF Electricity (kWh) (New)`) - MIN(`BF Electricity (kWh) (New)`) AS range_BF_Electricity_kWh_New,
MAX(`EAF Electricity (kWh) (New)`) - MIN(`EAF Electricity (kWh) (New)`) AS range_EAF_Electricity_kWh_New,
MAX(`LRF Electricity (kWh) (New)`) - MIN(`LRF Electricity (kWh) (New)`) AS range_LRF_Electricity_kWh_New,
MAX(`Total Electricity Consumption (kWh)`) - MIN(`Total Electricity Consumption (kWh)`) AS range_Total_Electricity_Consumption_kWh,
MAX(`New Electricity Consumption (kWh) Total`) - MIN(`New Electricity Consumption (kWh) Total`) AS range_New_Electricity_Consumption_kWh_Total,
MAX(`Scrap Steel (%)`) - MIN(`Scrap Steel (%)`) AS range_Scrap_Steel_percent,
MAX(`New Scrap Steel (%)`) - MIN(`New Scrap Steel (%)`) AS range_New_Scrap_Steel_percent,
MAX(`New DRI or Pig Iron (%)`) - MIN(`New DRI or Pig Iron (%)`) AS range_NewDRI_or_PigIron_percent,
MAX(`DRI or Pig Iron (%)`) - MIN(`DRI or Pig Iron (%)`) AS range_DRI_or_PigIron_percent,
MAX(`Iron Ore (%)`) - MIN(`Iron Ore (%)`) AS range_Iron_Ore_percent,
MAX(`New Iron Ore (%)`) - MIN(`New Iron Ore (%)`) AS range_New_Iron_Ore_percent,
MAX(`Phosphorus (%)`) - MIN(`Phosphorus (%)`) AS range_Phosphorus_percent,
MAX(`Carbon (%)`) - MIN(`Carbon (%)`) AS range_Carbon_percent
FROM nrmfresh;


######################## Third Moment Business Decision / Skewness ######################

SELECT
(
SUM(POWER(`BF Electricity (kWh)`- (SELECT AVG(`BF Electricity (kWh)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`BF Electricity (kWh)`) FROM nrmfresh), 3))
) AS skewness_BF_Electricity_kWh,
(
SUM(POWER(`EAF Electricity (kWh)`- (SELECT AVG(`EAF Electricity (kWh)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`EAF Electricity (kWh)`) FROM nrmfresh), 3))
) AS skewness_EAF_Electricity_kWh,
(
SUM(POWER(`LRF Electricity (kWh)`- (SELECT AVG(`LRF Electricity (kWh)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`LRF Electricity (kWh)`) FROM nrmfresh), 3))
) AS skewness_LRF_Electricity_kWh,
(
SUM(POWER(`BF Electricity (kWh) (New)`- (SELECT AVG(`BF Electricity (kWh) (New)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`BF Electricity (kWh) (New)`) FROM nrmfresh), 3))
) AS skewness_BF_Electricity_kWh_New,
(
SUM(POWER(`EAF Electricity (kWh) (New)`- (SELECT AVG(`EAF Electricity (kWh) (New)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`EAF Electricity (kWh) (New)`) FROM nrmfresh), 3))
) AS skewness_EAF_Electricity_kWh_New,
(
SUM(POWER(`LRF Electricity (kWh) (New)`- (SELECT AVG(`LRF Electricity (kWh) (New)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`LRF Electricity (kWh) (New)`) FROM nrmfresh), 3))
) AS skewness_LRF_Electricity_kWh_New,
(
SUM(POWER(`Total Electricity Consumption (kWh)`- (SELECT AVG(`Total Electricity Consumption (kWh)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Total Electricity Consumption (kWh)`) FROM nrmfresh), 3))
) AS skewness_Total_Electricity_Consumption_kWh,
(
SUM(POWER(`New Electricity Consumption (kWh) Total`- (SELECT AVG(`New Electricity Consumption (kWh) Total`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Electricity Consumption (kWh) Total`) FROM nrmfresh), 3))
) AS skewness_New_Electricity_Consumption_kWh_Total,
(
SUM(POWER(`Scrap Steel (%)`- (SELECT AVG(`Scrap Steel (%)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Scrap Steel (%)`) FROM nrmfresh), 3))
) AS skewness_Scrap_Steel_percent,
(
SUM(POWER(`New Scrap Steel (%)`- (SELECT AVG(`New Scrap Steel (%)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Scrap Steel (%)`) FROM nrmfresh), 3))
) AS skewness_New_Scrap_Steel_percent,
(
SUM(POWER(`Iron Ore (%)`- (SELECT AVG(`Iron Ore (%)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Iron Ore (%)`) FROM nrmfresh), 3))
) AS skewness_Iron_Ore_percent,
(
SUM(POWER(`New Iron Ore (%)`- (SELECT AVG(`New Iron Ore (%)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Iron Ore (%)`) FROM nrmfresh), 3))
) AS skewness_New_Iron_Ore_percent,
(
SUM(POWER(`DRI or Pig Iron (%)`- (SELECT AVG(`DRI or Pig Iron (%)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`DRI or Pig Iron (%)`) FROM nrmfresh), 3))
) AS skewness_DRI_or_PigIron_percent,
(
SUM(POWER(`New DRI or Pig Iron (%)`- (SELECT AVG(`New DRI or Pig Iron (%)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`New DRI or Pig Iron (%)`) FROM nrmfresh), 3))
) AS skewness_NewDRI_or_PigIron_percent,
(
SUM(POWER(`Phosphorus (%)`- (SELECT AVG(`Phosphorus (%)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Phosphorus (%)`) FROM nrmfresh), 3))
) AS skewness_Phosphorus_percent,
(
SUM(POWER(`Carbon (%)`- (SELECT AVG(`Carbon (%)`) FROM nrmfresh), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Carbon (%)`) FROM nrmfresh), 3))
) AS skewness_Carbon_percent
FROM nrmfresh;

############################### Fourth Moment Business Decision / Kurtosis #####################################

SELECT
(
(SUM(POWER(`BF Electricity (kWh)`- (SELECT AVG(`BF Electricity (kWh)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`BF Electricity (kWh)`) FROM nrmfresh), 4)))-3
) AS kurtosis_BF_Electricity_kWh,
(
(SUM(POWER(`EAF Electricity (kWh)`- (SELECT AVG(`EAF Electricity (kWh)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`EAF Electricity (kWh)`) FROM nrmfresh), 4)))-3
) AS kurtosis_EAF_Electricity_kWh,
(
(SUM(POWER(`LRF Electricity (kWh)`- (SELECT AVG(`LRF Electricity (kWh)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`LRF Electricity (kWh)`) FROM nrmfresh), 4)))-3
) AS kurtosis_LRF_Electricity_kWh,
(
(SUM(POWER(`BF Electricity (kWh) (New)`- (SELECT AVG(`BF Electricity (kWh) (New)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`BF Electricity (kWh) (New)`) FROM nrmfresh), 4)))-3
) AS Kurtosis_BF_Electricity_kWh_New,
(
(SUM(POWER(`EAF Electricity (kWh) (New)`- (SELECT AVG(`EAF Electricity (kWh) (New)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`EAF Electricity (kWh) (New)`) FROM nrmfresh), 4)))-3
) AS kurtosis_EAF_Electricity_kWh_New,
(
(SUM(POWER(`LRF Electricity (kWh) (New)`- (SELECT AVG(`LRF Electricity (kWh) (New)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`LRF Electricity (kWh) (New)`) FROM nrmfresh), 4)))-3
) AS kurtosis_LRF_Electricity_kWh_New,
(
(SUM(POWER(`Total Electricity Consumption (kWh)`- (SELECT AVG(`Total Electricity Consumption (kWh)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Total Electricity Consumption (kWh)`) FROM nrmfresh), 4)))-3
) AS kurtosis_Total_Electricity_Consumption_kWh,
(
(SUM(POWER(`New Electricity Consumption (kWh) Total`- (SELECT AVG(`New Electricity Consumption (kWh) Total`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Electricity Consumption (kWh) Total`) FROM nrmfresh), 4)))-3
) AS kurtosis_New_Electricity_Consumption_kWh_Total,
(
(SUM(POWER(`Scrap Steel (%)`- (SELECT AVG(`Scrap Steel (%)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Scrap Steel (%)`) FROM nrmfresh), 4)))-3
) AS kurtosis_Scrap_Steel_percent,
(
(SUM(POWER(`New Scrap Steel (%)`- (SELECT AVG(`New Scrap Steel (%)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Scrap Steel (%)`) FROM nrmfresh), 4)))-3
) AS kurtosis_New_Scrap_Steel_percent,
(
(SUM(POWER(`Iron Ore (%)`- (SELECT AVG(`Iron Ore (%)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Iron Ore (%)`) FROM nrmfresh), 4)))-3
) AS kurtosis_Iron_Ore_percent,
(
(SUM(POWER(`New Iron Ore (%)`- (SELECT AVG(`New Iron Ore (%)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`New Iron Ore (%)`) FROM nrmfresh), 4)))-3
) AS kurtosis_New_Iron_Ore_percent,
(
(SUM(POWER(`DRI or Pig Iron (%)`- (SELECT AVG(`DRI or Pig Iron (%)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`DRI or Pig Iron (%)`) FROM nrmfresh), 4)))-3
) AS kurtosis_DRI_or_PigIron_percent,
(
(SUM(POWER(`New DRI or Pig Iron (%)`- (SELECT AVG(`New DRI or Pig Iron (%)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`New DRI or Pig Iron (%)`) FROM nrmfresh), 4)))-3
) AS kurtosis_NewDRI_or_PigIron_percent,
(
(SUM(POWER(`Phosphorus (%)`- (SELECT AVG(`Phosphorus (%)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Phosphorus (%)`) FROM nrmfresh), 4)))-3
) AS kurtosis_Phosphorus_percent,
(
(SUM(POWER(`Carbon (%)`- (SELECT AVG(`Carbon (%)`) FROM nrmfresh), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Carbon (%)`) FROM nrmfresh), 4)))-3
) AS kurtosis_Carbon_percent
FROM nrmfresh;





















