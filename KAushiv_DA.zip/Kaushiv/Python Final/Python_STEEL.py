#####imported raw data from sql
import pandas as pd

import numpy as np

import matplotlib.pyplot as plt
df1 = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")

df1.info()

from sqlalchemy import create_engine,text


from urllib.parse import quote


user = 'root'

pw = 'gowtham12'

db = 'steel'

engine = create_engine(f"mysql+pymysql://{user}:{pw}@localhost/{db}")



df1.to_sql('steel1', con = engine, if_exists = 'replace', chunksize = None, index= False)

sql = "SELECT * FROM steel1;"


df = pd.read_sql_query(sql, engine)


df = pd.read_sql_query(text(sql), engine.connect())


print (df)



##########################First Moment Business Decision / Measures of Central Tendency#################################

################################# mean ##################################


mean_scrap_steel_percent = df['Scrap Steel (%)'].mean()
print(mean_scrap_steel_percent) 

mean_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].mean()
print(mean_DRI_or_Pig_Iron_percent)

mean_Iron_Ore_percent = df['Iron Ore (%)'].mean()
print(mean_Iron_Ore_percent)

mean_phosphorus_percent = df['Phosphorus (%)'].mean()
print(mean_phosphorus_percent)

mean_carbon_percent = df['Carbon (%)'].mean()
print(mean_carbon_percent)

mean_BF_Electricity_kWh = df['BF Electricity (kWh)'].mean()
print(mean_BF_Electricity_kWh)

mean_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].mean()
print(mean_EAF_Electricity_kWh)

mean_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].mean()
print(mean_LRF_Electricity_kWh)

mean_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].mean()
print(mean_Total_Electricity_Consumption_kWh)

mean_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].mean()
print(mean_NewDRI_or_Pig_Iron_percent)

mean_NewIron_Ore_percent = df['New Iron Ore (%)'].mean()
print(mean_NewIron_Ore_percent)

mean_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].mean()
print(mean_New_Electricity_Consumption_kWh_Total)

mean_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].mean()
print(mean_BF_Electricity_kWh_New)

mean_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].mean()
print(mean_EAF_Electricity_kWh_New)

mean_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].mean()
print(mean_LRF_Electricity_kWh_New)


##################### median ################################


median_scrap_steel_percent = df['Scrap Steel (%)'].median()
print(median_scrap_steel_percent)

median_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].median()
print(median_DRI_or_Pig_Iron_percent)

median_Iron_Ore_percent = df['Iron Ore (%)'].median()
print(median_Iron_Ore_percent)

median_phosphorus_percent = df['Phosphorus (%)'].median()
print(median_phosphorus_percent)

median_carbon_percent = df['Carbon (%)'].median()
print(median_carbon_percent)

median_BF_Electricity_kWh = df['BF Electricity (kWh)'].median()
print(median_BF_Electricity_kWh)

median_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].median()
print(median_EAF_Electricity_kWh)

median_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].median()
print(median_LRF_Electricity_kWh)

median_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].median()
print(median_Total_Electricity_Consumption_kWh)

median_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].median()
print(median_NewDRI_or_Pig_Iron_percent)

median_NewIron_Ore_percent = df['New Iron Ore (%)'].median()
print(median_NewIron_Ore_percent)

median_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].median()
print(median_New_Electricity_Consumption_kWh_Total)

median_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].median()
print(median_BF_Electricity_kWh_New)

median_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].median()
print(median_EAF_Electricity_kWh_New)

median_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].median()
print(median_LRF_Electricity_kWh_New)


####################  mode  #############################

mode_scrap_steel_percent = df['Scrap Steel (%)'].mode()
print(mode_scrap_steel_percent)

mode_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].mode()
print(mode_DRI_or_Pig_Iron_percent)

mode_Iron_Ore_percent = df['Iron Ore (%)'].mode()
print(mode_Iron_Ore_percent)

mode_phosphorus_percent = df['Phosphorus (%)'].mode()
print(mode_phosphorus_percent)

mode_carbon_percent = df['Carbon (%)'].mode()
print(mode_carbon_percent)

mode_BF_Electricity_kWh = df['BF Electricity (kWh)'].mode()
print(mode_BF_Electricity_kWh)

mode_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].mode()
print(mode_EAF_Electricity_kWh)

mode_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].mode()
print(mean_LRF_Electricity_kWh)

mode_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].mode()
print(mode_Total_Electricity_Consumption_kWh)

mode_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].mode()
print(mode_NewDRI_or_Pig_Iron_percent)

mode_NewIron_Ore_percent = df['New Iron Ore (%)'].mode()
print(mode_NewIron_Ore_percent)

mode_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].mode()
print(mode_New_Electricity_Consumption_kWh_Total)

mode_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].mode()
print(mode_BF_Electricity_kWh_New)

mode_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].mode()
print(mode_EAF_Electricity_kWh_New)

mode_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].mode()
print(mode_LRF_Electricity_kWh_New)



################################### Second Moment Business Decision / Measures of Dispersion


################# Variance #######################

var_scrap_steel_percent = df['Scrap Steel (%)'].var()
print(var_scrap_steel_percent)

var_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].var()
print(var_DRI_or_Pig_Iron_percent)

var_Iron_Ore_percent = df['Iron Ore (%)'].var()
print(var_Iron_Ore_percent)

var_phosphorus_percent = df['Phosphorus (%)'].var()
print(var_phosphorus_percent)

var_carbon_percent = df['Carbon (%)'].var()
print(var_carbon_percent)

var_BF_Electricity_kWh = df['BF Electricity (kWh)'].var()
print(var_BF_Electricity_kWh)

var_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].var()
print(var_EAF_Electricity_kWh)

var_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].var()
print(var_LRF_Electricity_kWh)

var_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].var()
print(var_Total_Electricity_Consumption_kWh)

var_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].var()
print(var_NewDRI_or_Pig_Iron_percent)

var_NewIron_Ore_percent = df['New Iron Ore (%)'].var()
print(var_NewIron_Ore_percent)

var_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].var()
print(var_New_Electricity_Consumption_kWh_Total)

var_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].var()
print(var_BF_Electricity_kWh_New)

var_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].var()
print(var_EAF_Electricity_kWh_New)

var_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].var()
print(var_LRF_Electricity_kWh_New)


################# Standard Deviation ###################



stddev_scrap_steel_percent = df['Scrap Steel (%)'].std()
print(stddev_scrap_steel_percent)

stddev_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].std()
print(stddev_DRI_or_Pig_Iron_percent)

stddev_Iron_Ore_percent = df['Iron Ore (%)'].std()
print(stddev_Iron_Ore_percent)

stddev_phosphorus_percent = df['Phosphorus (%)'].std()
print(stddev_phosphorus_percent)

stddev_carbon_percent = df['Carbon (%)'].std()
print(stddev_carbon_percent)

stddev_BF_Electricity_kWh = df['BF Electricity (kWh)'].std()
print(stddev_BF_Electricity_kWh)

stddev_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].std()
print(stddev_EAF_Electricity_kWh)

stddev_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].std()
print(stddev_LRF_Electricity_kWh)

stddev_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].std()
print(stddev_Total_Electricity_Consumption_kWh)

stddev_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].std()
print(stddev_NewDRI_or_Pig_Iron_percent)

stddev_NewIron_Ore_percent = df['New Iron Ore (%)'].std()
print(stddev_NewIron_Ore_percent)

stddev_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].std()
print(stddev_New_Electricity_Consumption_kWh_Total)

stddev_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].std()
print(stddev_BF_Electricity_kWh_New)

stddev_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].std()
print(stddev_EAF_Electricity_kWh_New)

stddev_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].std()
print(stddev_LRF_Electricity_kWh_New)


################ Range #############################

range_scrap_steel_percent = df['Scrap Steel (%)'].max() - df['Scrap Steel (%)'].min()
print(range_scrap_steel_percent)

range_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].max()-df['DRI or Pig Iron (%)'].min()
print(range_DRI_or_Pig_Iron_percent)

range_Iron_Ore_percent = df['Iron Ore (%)'].max()-df['Iron Ore (%)'].min()
print(range_Iron_Ore_percent)

range_phosphorus_percent = df['Phosphorus (%)'].max()-df['Phosphorus (%)'].min()
print(range_phosphorus_percent)

range_carbon_percent = df['Carbon (%)'].max()-df['Carbon (%)'].min()
print(range_carbon_percent)

range_BF_Electricity_kWh = df['BF Electricity (kWh)'].max()-df['BF Electricity (kWh)'].min()
print(range_BF_Electricity_kWh)

range_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].max()-df['EAF Electricity (kWh)'].min()
print(range_EAF_Electricity_kWh)

range_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].max()-df['LRF Electricity (kWh)'].min()
print(range_LRF_Electricity_kWh)

range_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].max()-df['Total Electricity Consumption (kWh)'].min()
print(range_Total_Electricity_Consumption_kWh)

range_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].max()-df['New DRI or Pig Iron (%)'].min()
print(range_NewDRI_or_Pig_Iron_percent)

range_NewIron_Ore_percent = df['New Iron Ore (%)'].max()-df['New Iron Ore (%)'].min()
print(range_NewIron_Ore_percent)

range_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].max()-df['New Electricity Consumption (kWh) Total'].min()
print(range_New_Electricity_Consumption_kWh_Total)

range_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].max()-df['BF Electricity (kWh) (New)'].min()
print(range_BF_Electricity_kWh_New)

range_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].max()-df['EAF Electricity (kWh) (New)'].min()
print(range_EAF_Electricity_kWh_New)

range_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].max()-df['LRF Electricity (kWh) (New)'].min()
print(range_LRF_Electricity_kWh_New)


################################## Third Moment Business Decision / Skewness ###################################

skewness_scrap_steel_percent = df['Scrap Steel (%)'].skew()
print(skewness_scrap_steel_percent)

skewness_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].skew()
print(skewness_DRI_or_Pig_Iron_percent)

skewness_Iron_Ore_percent = df['Iron Ore (%)'].skew()
print(skewness_Iron_Ore_percent)

skewness_phosphorus_percent = df['Phosphorus (%)'].skew()
print(skewness_phosphorus_percent)

skewness_carbon_percent = df['Carbon (%)'].skew()
print(skewness_carbon_percent)

skewness_BF_Electricity_kWh = df['BF Electricity (kWh)'].skew()
print(skewness_BF_Electricity_kWh)

skewness_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].skew()
print(skewness_EAF_Electricity_kWh)

skewness_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].skew()
print(skewness_LRF_Electricity_kWh)

skewness_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].skew()
print(skewness_Total_Electricity_Consumption_kWh)

skewness_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].skew()
print(skewness_NewDRI_or_Pig_Iron_percent)

skewness_NewIron_Ore_percent = df['New Iron Ore (%)'].skew()
print(skewness_NewIron_Ore_percent)

skewness_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].skew()
print(skewness_New_Electricity_Consumption_kWh_Total)

skewness_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].skew()
print(skewness_BF_Electricity_kWh_New)

skewness_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].skew()
print(skewness_EAF_Electricity_kWh_New)

skewness_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].skew()
print(skewness_LRF_Electricity_kWh_New)



################################## Fourth Moment Business Decision / Kurtosis ###################################

kurtosis_scrap_steel_percent = df['Scrap Steel (%)'].kurtosis()
print(kurtosis_scrap_steel_percent)

kurtosis_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].kurtosis()
print(kurtosis_DRI_or_Pig_Iron_percent)

kurtosis_Iron_Ore_percent = df['Iron Ore (%)'].kurtosis()
print(kurtosis_Iron_Ore_percent)

kurtosis_phosphorus_percent = df['Phosphorus (%)'].kurtosis()
print(kurtosis_phosphorus_percent)

kurtosis_carbon_percent = df['Carbon (%)'].kurtosis()
print(kurtosis_carbon_percent)

kurtosis_BF_Electricity_kWh = df['BF Electricity (kWh)'].kurtosis()
print(kurtosis_BF_Electricity_kWh)

kurtosis_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].kurtosis()
print(kurtosis_EAF_Electricity_kWh)

kurtosis_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].kurtosis()
print(kurtosis_LRF_Electricity_kWh)

kurtosis_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].kurtosis()
print(kurtosis_Total_Electricity_Consumption_kWh)

kurtosis_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].kurtosis()
print(kurtosis_NewDRI_or_Pig_Iron_percent)

kurtosis_NewIron_Ore_percent = df['New Iron Ore (%)'].kurtosis()
print(kurtosis_NewIron_Ore_percent)

kurtosis_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].kurtosis()
print(kurtosis_New_Electricity_Consumption_kWh_Total)

kurtosis_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].kurtosis()
print(kurtosis_BF_Electricity_kWh_New)

kurtosis_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].kurtosis()
print(kurtosis_EAF_Electricity_kWh_New)

kurtosis_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].kurtosis()
print(kurtosis_LRF_Electricity_kWh_New)


############################# Graphical Representation ###################################


import pandas as pd 

import numpy as np

import matplotlib.pyplot as plt

df = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")

plt.figure(figsize=(10, 6))


############ creating With histogram ###############


plt.hist(df['Scrap Steel (%)'], bins=20, color = 'green', edgecolor = "pink")
plt.title('Scrap Steel')
plt.tight_layout()
plt.show() 


plt.hist(df['DRI or Pig Iron (%)'],bins=20, color = 'pink', edgecolor = "green")
plt.title('DRI or Pig Iron (%)')
plt.tight_layout()
plt.show() 

plt.hist(df['Iron Ore (%)'],bins=20, color = 'black', edgecolor = "red")
plt.title('Iron Ore (%)')
plt.tight_layout()
plt.show() 


plt.hist(df['Phosphorus (%)'],bins=20, color = 'orange', edgecolor = "skyblue")
plt.title('Phosphorus (%)')
plt.tight_layout()
plt.show() 

plt.hist(df['Carbon (%)'],bins=20, color = 'yellow', edgecolor = "red")
plt.title('Carbon (%)')
plt.tight_layout()
plt.show() 

plt.hist(df['BF Electricity (kWh)'],bins=20, color = 'white', edgecolor = "blue")
plt.title('BF Electricity (kWh)')
plt.tight_layout()
plt.show() 

plt.hist(df['EAF Electricity (kWh)'],bins=20, color = 'green', edgecolor = "yellow")
plt.title('EAF Electricity (kWh)')
plt.tight_layout()
plt.show() 

plt.hist(df['LRF Electricity (kWh)'],bins=20, color = 'red', edgecolor = "black")
plt.title('LRF Electricity (kWh)')
plt.tight_layout()
plt.show() 

plt.hist(df['Total Electricity Consumption (kWh)'],bins=20, color = 'pink', edgecolor = "green")
plt.title('Total Electricity Consumption (kWh)')
plt.tight_layout()
plt.show() 

plt.hist(df['New DRI or Pig Iron (%)'],bins=20, color = 'pink', edgecolor = "green")
plt.title('New DRI or Pig Iron (%)')
plt.tight_layout()
plt.show() 

plt.hist(df['New Iron Ore (%)'],bins=20, color = 'pink', edgecolor = "green")
plt.title('New Iron Ore (%)')
plt.tight_layout()
plt.show() 

plt.hist(df['New Electricity Consumption (kWh) Total'],bins=20, color = 'pink', edgecolor = "green")
plt.title('New Electricity Consumption (kWh) Total')
plt.tight_layout()
plt.show() 


plt.hist(df['BF Electricity (kWh) (New)'],bins=20, color = 'pink', edgecolor = "green")
plt.title('BF Electricity (kWh) (New)')
plt.tight_layout()
plt.show() 

plt.hist(df['EAF Electricity (kWh) (New)'],bins=20, color = 'pink', edgecolor = "green")
plt.title('EAF Electricity (kWh) (New)')
plt.tight_layout()
plt.show() 

plt.hist(df['LRF Electricity (kWh) (New)'],bins=20, color = 'pink', edgecolor = "green")
plt.title('LRF Electricity (kWh) (New)')
plt.tight_layout()
plt.show() 

########################### Typecasting #################################

import pandas as pd
df = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")

df['Scrap Steel (%)'] = df['Scrap Steel (%)'].astype(float)
print(df['Scrap Steel (%)'].dtypes)

df['DRI or Pig Iron (%)'] = df['DRI or Pig Iron (%)'].astype(float)
print(df['DRI or Pig Iron (%)'].dtypes)

df['Iron Ore (%)'] = df['Iron Ore (%)'].astype(float)
print(df['Iron Ore (%)'].dtypes)

df['Total Electricity Consumption (kWh)'] = df['Total Electricity Consumption (kWh)'].astype(float)
print(df['Total Electricity Consumption (kWh)'].dtypes)

df['BF Electricity (kWh)'] = df['BF Electricity (kWh)'].astype(float)
print(df['BF Electricity (kWh)'].dtypes)

df['EAF Electricity (kWh)'] = df['EAF Electricity (kWh)'].astype(float)
print(df['EAF Electricity (kWh)'].dtypes)

df['LRF Electricity (kWh)'] = df['LRF Electricity (kWh)'].astype(float)
print(df['LRF Electricity (kWh)'].dtypes)

df['New Electricity Consumption (kWh) Total'] = df['New Electricity Consumption (kWh) Total'].astype(float)
print(df['New Electricity Consumption (kWh) Total'].dtypes)


df['New DRI or Pig Iron (%)'] = df['New DRI or Pig Iron (%)'].astype(float)
print(df['New DRI or Pig Iron (%)'].dtypes)

df['New Iron Ore (%)'] = df['Scrap Steel (%)'].astype(float)
print(df['Scrap Steel (%)'].dtypes)

df['Scrap Steel (%)'] = df['Scrap Steel (%)'].astype(float)
print(df['Scrap Steel (%)'].dtypes)

df['BF Electricity (kWh) (New)'] = df['BF Electricity (kWh) (New)'].astype(float)
print(df['BF Electricity (kWh) (New)'].dtypes)

df['EAF Electricity (kWh) (New)'] = df['EAF Electricity (kWh) (New)'].astype(float)
print(df['EAF Electricity (kWh) (New)'].dtypes)

df['LRF Electricity (kWh) (New)'] = df['LRF Electricity (kWh) (New)'].astype(float)
print(df['LRF Electricity (kWh) (New)'].dtypes)

df.dtypes

####################### Handling Duplicates ############################


import pandas as pd
df = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")
df.drop_duplicates(inplace = True)
print(df)


############################ Outlier Treatment ##################################

import pandas as pd
import numpy as np 
df = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")

# Function to replace outliers with median using IQR
def treat_outliers_iqr(df, column):
    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    df[column] = np.where(df[column] < lower_bound, df[column].median(), df[column])
    df[column] = np.where(df[column] > upper_bound, df[column].median(), df[column])
    return df



# Columns to treat for outliers
columns_to_treat = [ 'Scrap Steel (%)', 
    'DRI or Pig Iron (%)', 'Iron Ore (%)', 'Phosphorus (%)', 'Carbon (%)',
    'BF Electricity (kWh)', 'EAF Electricity (kWh)', 'LRF Electricity (kWh)',
    'Total Electricity Consumption (kWh)',
    'New DRI or Pig Iron (%)', 'New Iron Ore (%)',
    'New Electricity Consumption (kWh) Total',
    'BF Electricity (kWh) (New)', 'EAF Electricity (kWh) (New)',
    'LRF Electricity (kWh) (New)'
]

# Apply outlier treatment to each column
for col in columns_to_treat:
    df = treat_outliers_iqr(df, col)

# Print treated DataFrame
print(df) 


#################### Missing values ##########################


import pandas as pd
df = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")
df.dropna(inplace = True)
print(df)


####################### Normalization ########################

import pandas as pd

from sklearn.preprocessing import MinMaxScaler
df = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")
scaler = MinMaxScaler()
df['Scrap Steel (%)'] = scaler.fit_transform(df[['Scrap Steel (%)']])

df['DRI or Pig Iron (%)'] = scaler.fit_transform(df[['DRI or Pig Iron (%)']])

df['Iron Ore (%)'] = scaler.fit_transform(df[['Iron Ore (%)']])

df['Phosphorus (%)'] = scaler.fit_transform(df[['Phosphorus (%)']])

df['Carbon (%)'] = scaler.fit_transform(df[['Carbon (%)']])

df['BF Electricity (kWh)'] = scaler.fit_transform(df[['BF Electricity (kWh)']])

df['EAF Electricity (kWh)'] = scaler.fit_transform(df[['EAF Electricity (kWh)']])

df['LRF Electricity (kWh)'] = scaler.fit_transform(df[['LRF Electricity (kWh)']])

df['Total Electricity Consumption (kWh)'] = scaler.fit_transform(df[['Total Electricity Consumption (kWh)']])

df['New DRI or Pig Iron (%)'] = scaler.fit_transform(df[['New DRI or Pig Iron (%)']])

df['New Iron Ore (%)'] = scaler.fit_transform(df[['New Iron Ore (%)']])

df['New Electricity Consumption (kWh) Total'] = scaler.fit_transform(df[['New Electricity Consumption (kWh) Total']])

df['BF Electricity (kWh) (New)'] = scaler.fit_transform(df[['BF Electricity (kWh) (New)']])

df['EAF Electricity (kWh) (New)'] = scaler.fit_transform(df[['EAF Electricity (kWh) (New)']])

df['LRF Electricity (kWh) (New)'] = scaler.fit_transform(df[['LRF Electricity (kWh) (New)']])


print(df)


####################### Discretization/Binning/Grouping ################################


import pandas as pd
#calulate from the normalization
df['Scrap Steel (%)'] = pd.cut(df['Scrap Steel (%)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])
print(df)

df['DRI or Pig Iron (%)'] = pd.cut(df['DRI or Pig Iron (%)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['Iron Ore (%)'] = pd.cut(df['Iron Ore (%)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['Phosphorus (%)'] = pd.cut(df['Phosphorus (%)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['Carbon (%)'] = pd.cut(df['Carbon (%)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['BF ELectricity (kWh)'] = pd.cut(df['BF Electricity (kWh)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['EAF ELectricity (kWh)'] = pd.cut(df['EAF Electricity (kWh)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['LRF ELectricity (kWh)'] = pd.cut(df['LRF Electricity (kWh)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['Total Electricity Consumption (kWh)'] = pd.cut(df['Total Electricity Consumption (kWh)'],bins = 3, labels = ['0 - 0.5%','0.5 - 1%','1% & above'])


df['New DRI or Pig Iron (%)'] = pd.cut(df['New DRI or Pig Iron (%)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['New Iron Ore (%)'] = pd.cut(df['New Iron Ore (%)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['New Electricity Consumption (kWh) Total'] = pd.cut(df['New Electricity Consumption (kWh) Total'],bins = 3, labels = ['0 - 0.5%','0.5 - 1%','1% & above'])



df['BF ELectricity (kWh) (New)'] = pd.cut(df['BF Electricity (kWh) (New)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['EAF ELectricity (kWh) (New)'] = pd.cut(df['EAF Electricity (kWh) (New)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])


df['LRF ELectricity (kWh) (New)'] = pd.cut(df['BF Electricity (kWh) (New)'], bins= 3, labels=['0-0.5%', '0.5% - 1', '1% & above'])
print(df)

############################### dummy variables #########################################

import pandas as pd

# Assuming df is your DataFrame containing the columns
columns_to_dummy = ['Scrap Steel (%)', 'DRI or Pig Iron (%)', 'Iron Ore (%)', 
                    'Phosphorus (%)', 'Carbon (%)', 'BF Electricity (kWh)', 
                    'EAF Electricity (kWh)', 'LRF Electricity (kWh)', 
                    'Total Electricity Consumption (kWh)', 'New DRI or Pig Iron (%)', 
                    'New Iron Ore (%)', 'New Electricity Consumption (kWh) Total', 
                    'BF Electricity (kWh) (New)', 'EAF Electricity (kWh) (New)', 
                    'LRF Electricity (kWh) (New)']

# Assuming df is your DataFrame
df_with_dummies = pd.get_dummies(df, columns=columns_to_dummy)

df.dtypes


print(df)

############################ Transformations ##################################

########### this is not requried at this moment #############
import pandas as pd
data = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")
data['Value_log'] = np.log(data['Value'])
print(data)


################### 4 Business Moments After Data Preprocessing #########################


#dataset taken from normalization

##########################First Moment Business Decision / Measures of Central Tendency#################################

################################# mean ##################################


mean_scrap_steel_percent = df['Scrap Steel (%)'].mean()
print(mean_scrap_steel_percent) 

mean_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].mean()
print(mean_DRI_or_Pig_Iron_percent)

mean_Iron_Ore_percent = df['Iron Ore (%)'].mean()
print(mean_Iron_Ore_percent)

mean_phosphorus_percent = df['Phosphorus (%)'].mean()
print(mean_phosphorus_percent)

mean_carbon_percent = df['Carbon (%)'].mean()
print(mean_carbon_percent)

mean_BF_Electricity_kWh = df['BF Electricity (kWh)'].mean()
print(mean_BF_Electricity_kWh)

mean_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].mean()
print(mean_EAF_Electricity_kWh)

mean_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].mean()
print(mean_LRF_Electricity_kWh)

mean_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].mean()
print(mean_Total_Electricity_Consumption_kWh)

mean_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].mean()
print(mean_NewDRI_or_Pig_Iron_percent)

mean_NewIron_Ore_percent = df['New Iron Ore (%)'].mean()
print(mean_NewIron_Ore_percent)

mean_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].mean()
print(mean_New_Electricity_Consumption_kWh_Total)

mean_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].mean()
print(mean_BF_Electricity_kWh_New)

mean_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].mean()
print(mean_EAF_Electricity_kWh_New)

mean_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].mean()
print(mean_LRF_Electricity_kWh_New)


##################### median ################################


median_scrap_steel_percent = df['Scrap Steel (%)'].median()
print(median_scrap_steel_percent)

median_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].median()
print(median_DRI_or_Pig_Iron_percent)

median_Iron_Ore_percent = df['Iron Ore (%)'].median()
print(median_Iron_Ore_percent)

median_phosphorus_percent = df['Phosphorus (%)'].median()
print(median_phosphorus_percent)

median_carbon_percent = df['Carbon (%)'].median()
print(median_carbon_percent)

median_BF_Electricity_kWh = df['BF Electricity (kWh)'].median()
print(median_BF_Electricity_kWh)

median_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].median()
print(median_EAF_Electricity_kWh)

median_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].median()
print(median_LRF_Electricity_kWh)

median_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].median()
print(median_Total_Electricity_Consumption_kWh)

median_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].median()
print(median_NewDRI_or_Pig_Iron_percent)

median_NewIron_Ore_percent = df['New Iron Ore (%)'].median()
print(median_NewIron_Ore_percent)

median_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].median()
print(median_New_Electricity_Consumption_kWh_Total)

median_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].median()
print(median_BF_Electricity_kWh_New)

median_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].median()
print(median_EAF_Electricity_kWh_New)

median_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].median()
print(median_LRF_Electricity_kWh_New)


####################  mode  #############################

mode_scrap_steel_percent = df['Scrap Steel (%)'].mode()
print(mode_scrap_steel_percent)

mode_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].mode()
print(mode_DRI_or_Pig_Iron_percent)

mode_Iron_Ore_percent = df['Iron Ore (%)'].mode()
print(mode_Iron_Ore_percent)

mode_phosphorus_percent = df['Phosphorus (%)'].mode()
print(mode_phosphorus_percent)

mode_carbon_percent = df['Carbon (%)'].mode()
print(mode_carbon_percent)

mode_BF_Electricity_kWh = df['BF Electricity (kWh)'].mode()
print(mode_BF_Electricity_kWh)

mode_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].mode()
print(mode_EAF_Electricity_kWh)

mode_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].mode()
print(mean_LRF_Electricity_kWh)

mode_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].mode()
print(mode_Total_Electricity_Consumption_kWh)

mode_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].mode()
print(mode_NewDRI_or_Pig_Iron_percent)

mode_NewIron_Ore_percent = df['New Iron Ore (%)'].mode()
print(mode_NewIron_Ore_percent)

mode_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].mode()
print(mode_New_Electricity_Consumption_kWh_Total)

mode_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].mode()
print(mode_BF_Electricity_kWh_New)

mode_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].mode()
print(mode_EAF_Electricity_kWh_New)

mode_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].mode()
print(mode_LRF_Electricity_kWh_New)



################################### Second Moment Business Decision / Measures of Dispersion


################# Variance #######################

var_scrap_steel_percent = df['Scrap Steel (%)'].var()
print(var_scrap_steel_percent)

var_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].var()
print(var_DRI_or_Pig_Iron_percent)

var_Iron_Ore_percent = df['Iron Ore (%)'].var()
print(var_Iron_Ore_percent)

var_phosphorus_percent = df['Phosphorus (%)'].var()
print(var_phosphorus_percent)

var_carbon_percent = df['Carbon (%)'].var()
print(var_carbon_percent)

var_BF_Electricity_kWh = df['BF Electricity (kWh)'].var()
print(var_BF_Electricity_kWh)

var_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].var()
print(var_EAF_Electricity_kWh)

var_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].var()
print(var_LRF_Electricity_kWh)

var_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].var()
print(var_Total_Electricity_Consumption_kWh)

var_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].var()
print(var_NewDRI_or_Pig_Iron_percent)

var_NewIron_Ore_percent = df['New Iron Ore (%)'].var()
print(var_NewIron_Ore_percent)

var_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].var()
print(var_New_Electricity_Consumption_kWh_Total)

var_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].var()
print(var_BF_Electricity_kWh_New)

var_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].var()
print(var_EAF_Electricity_kWh_New)

var_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].var()
print(var_LRF_Electricity_kWh_New)


################# Standard Deviation ###################



stddev_scrap_steel_percent = df['Scrap Steel (%)'].std()
print(stddev_scrap_steel_percent)

stddev_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].std()
print(stddev_DRI_or_Pig_Iron_percent)

stddev_Iron_Ore_percent = df['Iron Ore (%)'].std()
print(stddev_Iron_Ore_percent)

stddev_phosphorus_percent = df['Phosphorus (%)'].std()
print(stddev_phosphorus_percent)

stddev_carbon_percent = df['Carbon (%)'].std()
print(stddev_carbon_percent)

stddev_BF_Electricity_kWh = df['BF Electricity (kWh)'].std()
print(stddev_BF_Electricity_kWh)

stddev_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].std()
print(stddev_EAF_Electricity_kWh)

stddev_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].std()
print(stddev_LRF_Electricity_kWh)

stddev_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].std()
print(stddev_Total_Electricity_Consumption_kWh)

stddev_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].std()
print(stddev_NewDRI_or_Pig_Iron_percent)

stddev_NewIron_Ore_percent = df['New Iron Ore (%)'].std()
print(stddev_NewIron_Ore_percent)

stddev_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].std()
print(stddev_New_Electricity_Consumption_kWh_Total)

stddev_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].std()
print(stddev_BF_Electricity_kWh_New)

stddev_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].std()
print(stddev_EAF_Electricity_kWh_New)

stddev_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].std()
print(stddev_LRF_Electricity_kWh_New)


################ Range #############################

range_scrap_steel_percent = df['Scrap Steel (%)'].max() - df['Scrap Steel (%)'].min()
print(range_scrap_steel_percent)

range_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].max()-df['DRI or Pig Iron (%)'].min()
print(range_DRI_or_Pig_Iron_percent)

range_Iron_Ore_percent = df['Iron Ore (%)'].max()-df['Iron Ore (%)'].min()
print(range_Iron_Ore_percent)

range_phosphorus_percent = df['Phosphorus (%)'].max()-df['Phosphorus (%)'].min()
print(range_phosphorus_percent)

range_carbon_percent = df['Carbon (%)'].max()-df['Carbon (%)'].min()
print(range_carbon_percent)

range_BF_Electricity_kWh = df['BF Electricity (kWh)'].max()-df['BF Electricity (kWh)'].min()
print(range_BF_Electricity_kWh)

range_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].max()-df['EAF Electricity (kWh)'].min()
print(range_EAF_Electricity_kWh)

range_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].max()-df['LRF Electricity (kWh)'].min()
print(range_LRF_Electricity_kWh)

range_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].max()-df['Total Electricity Consumption (kWh)'].min()
print(range_Total_Electricity_Consumption_kWh)

range_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].max()-df['New DRI or Pig Iron (%)'].min()
print(range_NewDRI_or_Pig_Iron_percent)

range_NewIron_Ore_percent = df['New Iron Ore (%)'].max()-df['New Iron Ore (%)'].min()
print(range_NewIron_Ore_percent)

range_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].max()-df['New Electricity Consumption (kWh) Total'].min()
print(range_New_Electricity_Consumption_kWh_Total)

range_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].max()-df['BF Electricity (kWh) (New)'].min()
print(range_BF_Electricity_kWh_New)

range_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].max()-df['EAF Electricity (kWh) (New)'].min()
print(range_EAF_Electricity_kWh_New)

range_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].max()-df['LRF Electricity (kWh) (New)'].min()
print(range_LRF_Electricity_kWh_New)


################################## Third Moment Business Decision / Skewness ###################################

skewness_scrap_steel_percent = df['Scrap Steel (%)'].skew()
print(skewness_scrap_steel_percent)

skewness_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].skew()
print(skewness_DRI_or_Pig_Iron_percent)

skewness_Iron_Ore_percent = df['Iron Ore (%)'].skew()
print(skewness_Iron_Ore_percent)

skewness_phosphorus_percent = df['Phosphorus (%)'].skew()
print(skewness_phosphorus_percent)

skewness_carbon_percent = df['Carbon (%)'].skew()
print(skewness_carbon_percent)

skewness_BF_Electricity_kWh = df['BF Electricity (kWh)'].skew()
print(skewness_BF_Electricity_kWh)

skewness_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].skew()
print(skewness_EAF_Electricity_kWh)

skewness_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].skew()
print(skewness_LRF_Electricity_kWh)

skewness_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].skew()
print(skewness_Total_Electricity_Consumption_kWh)

skewness_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].skew()
print(skewness_NewDRI_or_Pig_Iron_percent)

skewness_NewIron_Ore_percent = df['New Iron Ore (%)'].skew()
print(skewness_NewIron_Ore_percent)

skewness_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].skew()
print(skewness_New_Electricity_Consumption_kWh_Total)

skewness_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].skew()
print(skewness_BF_Electricity_kWh_New)

skewness_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].skew()
print(skewness_EAF_Electricity_kWh_New)

skewness_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].skew()
print(skewness_LRF_Electricity_kWh_New)



################################## Fourth Moment Business Decision / Kurtosis ###################################

kurtosis_scrap_steel_percent = df['Scrap Steel (%)'].kurtosis()
print(kurtosis_scrap_steel_percent)

kurtosis_DRI_or_Pig_Iron_percent = df['DRI or Pig Iron (%)'].kurtosis()
print(kurtosis_DRI_or_Pig_Iron_percent)

kurtosis_Iron_Ore_percent = df['Iron Ore (%)'].kurtosis()
print(kurtosis_Iron_Ore_percent)

kurtosis_phosphorus_percent = df['Phosphorus (%)'].kurtosis()
print(kurtosis_phosphorus_percent)

kurtosis_carbon_percent = df['Carbon (%)'].kurtosis()
print(kurtosis_carbon_percent)

kurtosis_BF_Electricity_kWh = df['BF Electricity (kWh)'].kurtosis()
print(kurtosis_BF_Electricity_kWh)

kurtosis_EAF_Electricity_kWh = df['EAF Electricity (kWh)'].kurtosis()
print(kurtosis_EAF_Electricity_kWh)

kurtosis_LRF_Electricity_kWh = df['LRF Electricity (kWh)'].kurtosis()
print(kurtosis_LRF_Electricity_kWh)

kurtosis_Total_Electricity_Consumption_kWh = df['Total Electricity Consumption (kWh)'].kurtosis()
print(kurtosis_Total_Electricity_Consumption_kWh)

kurtosis_NewDRI_or_Pig_Iron_percent = df['New DRI or Pig Iron (%)'].kurtosis()
print(kurtosis_NewDRI_or_Pig_Iron_percent)

kurtosis_NewIron_Ore_percent = df['New Iron Ore (%)'].kurtosis()
print(kurtosis_NewIron_Ore_percent)

kurtosis_New_Electricity_Consumption_kWh_Total = df['New Electricity Consumption (kWh) Total'].kurtosis()
print(kurtosis_New_Electricity_Consumption_kWh_Total)

kurtosis_BF_Electricity_kWh_New = df['BF Electricity (kWh) (New)'].kurtosis()
print(kurtosis_BF_Electricity_kWh_New)

kurtosis_EAF_Electricity_kWh_New = df['EAF Electricity (kWh) (New)'].kurtosis()
print(kurtosis_EAF_Electricity_kWh_New)

kurtosis_LRF_Electricity_kWh_New = df['LRF Electricity (kWh) (New)'].kurtosis()
print(kurtosis_LRF_Electricity_kWh_New)




############################### AUTO EDA ##################################################


import pandas as pd
import numpy as np


df = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")

df = df.iloc[:,:-3]
print(df)
# Sweetviz
###########
#pip install sweetviz
import tqdm as notebook_tqdm
import sweetviz as sv

s = sv.analyze(df)
s.show_html()


# Autoviz
###########
# pip install autoviz


from autoviz.AutoViz_Class import AutoViz_Class

av = AutoViz_Class()
a = av.AutoViz(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv", chart_format = 'html')

import os
os.getcwd()

# If the dependent variable is known:
a = av.AutoViz(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv") # depVar - target variable in your dataset



# D-Tale
########

# pip install dtale   # In case of any error then please install werkzeug appropriate version 
#(pip install werkzeug==2.0.3)
import dtale
import pandas as pd

df = pd.read_csv(r"C:\Users\TANUJA SUREKHA\Desktop\Project 360\SQL_STEEL.csv")

d = dtale.show(df)
d.open_browser()


# Pandas Profiling

############## DONE in JUPYTTER ################











































